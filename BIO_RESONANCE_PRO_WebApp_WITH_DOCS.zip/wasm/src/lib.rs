
use wasm_bindgen::prelude::*;
use bio_resonance_core::analyze;

#[wasm_bindgen]
pub fn analyze_molecule(input: f64) -> JsValue {
    let result = analyze(input);
    serde_wasm_bindgen::to_value(&result).unwrap()
}

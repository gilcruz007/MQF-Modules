
use serde::Serialize;
use crate::constants::PHI;

#[derive(Serialize)]
pub struct AnalysisResult {
    pub structural_delta: f64,
    pub frequency: f64,
    pub mode: String,
}

pub fn analyze(input: f64) -> AnalysisResult {
    let structural_delta = (input * PHI).tanh();
    let frequency = structural_delta * 10.0;

    let mode = if frequency >= 3.5 {
        "COMPARTMENTALIZATION".to_string()
    } else {
        "REGENERATION".to_string()
    };

    AnalysisResult {
        structural_delta,
        frequency,
        mode,
    }
}


import { runAnalysis } from '../wasm/bio_resonance';

export async function analyze(input: any) {
  return await runAnalysis(input);
}


import init, { analyze_molecule } from './bio_resonance';

export async function runAnalysis(input: any) {
  await init();
  return analyze_molecule(input);
}


import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

type Props = {
  structuralDelta: number;
  frequency: number;
};

export default function Charts({ structuralDelta, frequency }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    new Chart(ref.current, {
      type: 'bar',
      data: {
        labels: ['Structural Δ', 'Frequency'],
        datasets: [{
          label: 'Resonance Metrics',
          data: [structuralDelta, frequency]
        }]
      }
    });
  }, [structuralDelta, frequency]);

  return <canvas ref={ref}></canvas>;
}

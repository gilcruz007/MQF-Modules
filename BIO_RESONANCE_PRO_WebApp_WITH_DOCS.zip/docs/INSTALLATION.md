
# Installation Guide

## Requirements
- Node.js 18+
- Rust (stable toolchain)
- wasm-pack

## WebApp
```bash
cd webapp
npm install
npm run dev
```

## WASM
```bash
cd wasm
wasm-pack build --target web
```


# Usage

1. Provide molecular parameters.
2. Run analysis.
3. Inspect metrics and charts.
4. Export or compare results.

All results are deterministic.


# API Reference

## analyze_molecule(input: number)

### Input
- input: number

### Output
JSON:
{
  "structural_delta": number,
  "frequency": number,
  "mode": string
}

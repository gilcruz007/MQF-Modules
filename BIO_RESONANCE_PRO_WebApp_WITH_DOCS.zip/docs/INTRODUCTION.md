
# BIO-RESONANCE PRO – Introduction

BIO-RESONANCE PRO is an open, research-grade computational tool designed to analyze
molecular structural divergence using deterministic mathematical models.

The system is built with a clear separation between:
- Scientific computation (Rust)
- High-performance execution (WASM)
- Professional Web Interface

This software is intended for research and educational use only.
It is not a medical device.

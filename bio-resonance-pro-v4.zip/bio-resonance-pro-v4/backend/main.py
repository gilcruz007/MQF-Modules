"""
Bio-Resonance Pro v4.0 - Backend API
FastAPI server para análise molecular

Uso:
    uvicorn main:app --reload --port 8000

Documentação:
    http://localhost:8000/docs (Swagger UI)
    http://localhost:8000/redoc (ReDoc)
"""

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
import math
import uuid
import json

# ═══════════════════════════════════════════════════════════════════════════
# CONSTANTES FÍSICAS
# ═══════════════════════════════════════════════════════════════════════════

PHI = 1.618033988749895
PLANCK = 6.62607015e-34
BOLTZMANN = 1.380649e-23
AVOGADRO = 6.02214076e23
SPEED_OF_LIGHT = 2.99792458e8
AMU_TO_KG = 1.66053906660e-27

ATOM_DATA = {
    "C": {"mass": 12.011, "electronegativity": 2.55},
    "H": {"mass": 1.008, "electronegativity": 2.20},
    "O": {"mass": 15.999, "electronegativity": 3.44},
    "N": {"mass": 14.007, "electronegativity": 3.04},
    "P": {"mass": 30.974, "electronegativity": 2.19},
    "S": {"mass": 32.065, "electronegativity": 2.58},
}

# ═══════════════════════════════════════════════════════════════════════════
# SCHEMAS (Pydantic)
# ═══════════════════════════════════════════════════════════════════════════

class AtomCounts(BaseModel):
    """Contagem de átomos na molécula"""
    C: int = Field(default=0, ge=0, le=999, description="Número de átomos de Carbono")
    H: int = Field(default=0, ge=0, le=999, description="Número de átomos de Hidrogênio")
    O: int = Field(default=0, ge=0, le=999, description="Número de átomos de Oxigênio")
    N: int = Field(default=0, ge=0, le=999, description="Número de átomos de Nitrogênio")
    P: int = Field(default=0, ge=0, le=999, description="Número de átomos de Fósforo")
    S: int = Field(default=0, ge=0, le=999, description="Número de átomos de Enxofre")

class AnalysisParams(BaseModel):
    """Parâmetros de análise"""
    delta: float = Field(default=0.2, ge=0, le=1, description="Desvio estrutural")
    intensity: float = Field(default=50, ge=0, le=100, description="Intensidade do campo (%)")
    temperature: float = Field(default=310, ge=0, le=1000, description="Temperatura (K)")

class AnalysisRequest(BaseModel):
    """Requisição de análise molecular"""
    name: str = Field(default="Amostra", max_length=100, description="Nome da amostra")
    atoms: AtomCounts
    params: AnalysisParams
    
    class Config:
        schema_extra = {
            "example": {
                "name": "Glicose",
                "atoms": {"C": 6, "H": 12, "O": 6, "N": 0, "P": 0, "S": 0},
                "params": {"delta": 0.2, "intensity": 50, "temperature": 310}
            }
        }

class EnergyResult(BaseModel):
    """Resultado de energia vibracional"""
    joules: float
    electronVolts: float
    kjPerMol: float

class VibrationalMode(BaseModel):
    """Modo vibracional"""
    type: str
    label: str
    frequency: float
    intensity: float
    atom: str

class AnalysisResponse(BaseModel):
    """Resposta da análise molecular"""
    id: str
    name: str
    frequencyTHz: float
    frequencyHz: float
    wavelengthUm: float
    geoFactor: float
    phiFactor: float
    mode: str
    modeClass: str
    modeDescription: str
    molecularMass: float
    reducedMass: float
    polarity: float
    vibrationalModes: List[VibrationalMode]
    modesCount: Dict[str, int]
    energy: EnergyResult
    params: Dict[str, Any]
    timestamp: int
    engine: str = "api"
    version: str = "4.0.0"

class BatchAnalysisRequest(BaseModel):
    """Requisição de análise em lote"""
    samples: List[AnalysisRequest]

class ComparisonRequest(BaseModel):
    """Requisição de comparação"""
    analysis_a: AnalysisResponse
    analysis_b: AnalysisResponse

class StatsRequest(BaseModel):
    """Requisição de estatísticas"""
    analyses: List[AnalysisResponse]

# ═══════════════════════════════════════════════════════════════════════════
# FUNÇÕES DE CÁLCULO
# ═══════════════════════════════════════════════════════════════════════════

def calculate_molecular_mass(atoms: AtomCounts) -> float:
    """Calcula massa molecular total em g/mol"""
    return sum(
        getattr(atoms, atom) * ATOM_DATA[atom]["mass"]
        for atom in ATOM_DATA
    )

def calculate_reduced_mass(atoms: AtomCounts) -> float:
    """Calcula massa reduzida em kg"""
    masses = []
    for atom in ATOM_DATA:
        count = getattr(atoms, atom)
        if count > 0:
            mass_kg = ATOM_DATA[atom]["mass"] * AMU_TO_KG
            masses.extend([mass_kg] * count)
    
    if len(masses) < 2:
        return masses[0] if masses else 1e-27
    
    sum_inverse = sum(1/m for m in masses)
    return len(masses) / sum_inverse

def calculate_polarity(atoms: AtomCounts) -> float:
    """Calcula índice de polaridade"""
    total_atoms = sum(getattr(atoms, atom) for atom in ATOM_DATA)
    if total_atoms == 0:
        return 0.0
    
    ref_en = 2.5  # Carbono como referência
    weighted_sum = sum(
        getattr(atoms, atom) * abs(ATOM_DATA[atom]["electronegativity"] - ref_en)
        for atom in ATOM_DATA
    )
    
    return min(1.0, weighted_sum / (total_atoms * 1.5))

def estimate_vibrational_modes(atoms: AtomCounts) -> Dict[str, int]:
    """Estima número de modos vibracionais"""
    n = sum(getattr(atoms, atom) for atom in ATOM_DATA)
    if n < 2:
        return {"linear": 0, "nonLinear": 0, "total": 0}
    
    return {
        "linear": 3 * n - 5,
        "nonLinear": 3 * n - 6,
        "total": 3 * n - 6 if n > 2 else 3 * n - 5
    }

def generate_vibrational_modes(atoms: AtomCounts, base_freq: float) -> List[VibrationalMode]:
    """Gera modos vibracionais simulados"""
    modes = []
    mode_types = [
        ("stretching", "Estiramento", 1.0),
        ("bending", "Flexão", 0.5),
        ("rocking", "Balanço", 0.3),
        ("wagging", "Oscilação", 0.35),
        ("twisting", "Torção", 0.25),
    ]
    
    import random
    
    for atom in ATOM_DATA:
        count = getattr(atoms, atom)
        if count > 0:
            for mode_type, label, factor in mode_types:
                mass_effect = math.sqrt(12 / ATOM_DATA[atom]["mass"])
                freq = base_freq * factor * mass_effect * (1 + random.random() * 0.1)
                
                if len(modes) < 20:
                    modes.append(VibrationalMode(
                        type=mode_type,
                        label=f"{label} {atom}",
                        frequency=freq,
                        intensity=random.random() * 0.5 + 0.5,
                        atom=atom
                    ))
    
    return sorted(modes, key=lambda m: m.frequency)

def compute_frequency(request: AnalysisRequest) -> AnalysisResponse:
    """Calcula frequência de ressonância molecular em THz"""
    atoms = request.atoms
    params = request.params
    
    total_atoms = sum(getattr(atoms, atom) for atom in ATOM_DATA)
    
    if total_atoms == 0:
        return create_empty_response(request.name)
    
    # Propriedades moleculares
    molecular_mass = calculate_molecular_mass(atoms)
    reduced_mass = calculate_reduced_mass(atoms)
    polarity = calculate_polarity(atoms)
    modes_count = estimate_vibrational_modes(atoms)
    
    # Constante de força efetiva
    base_force_constant = 500.0
    polarity_modifier = 1 + polarity * 0.5
    delta_effect = math.log1p(params.delta * PHI * (1 + polarity))
    k_eff = base_force_constant * polarity_modifier * (1 + delta_effect)
    
    # Fatores de modificação
    t_ref = 310.0
    temp_factor = math.exp((params.temperature - t_ref) / (2 * t_ref))
    intensity_factor = 0.5 + (params.intensity / 100) * 0.5
    
    # Cálculo da frequência
    freq_rad = math.sqrt(k_eff / reduced_mass)
    freq_hz = freq_rad / (2 * math.pi)
    freq_thz = freq_hz * 1e-12
    
    # Aplicar modificadores
    resonance_freq_thz = freq_thz * temp_factor * intensity_factor
    resonance_freq_hz = resonance_freq_thz * 1e12
    
    # Comprimento de onda
    wavelength_um = (SPEED_OF_LIGHT / resonance_freq_hz) * 1e6
    
    # Fatores
    geo_factor = math.log1p(params.delta * PHI * (1 + polarity))
    phi_factor = PHI * (1 + params.delta)
    
    # Determinação do modo
    if resonance_freq_thz < 5:
        mode, mode_class = "REGENERAÇÃO", "regeneration"
        mode_description = "Frequência ideal para processos de regeneração celular"
    elif resonance_freq_thz < 20:
        mode, mode_class = "EQUILÍBRIO", "equilibrium"
        mode_description = "Zona de equilíbrio energético molecular"
    elif resonance_freq_thz < 50:
        mode, mode_class = "ATIVAÇÃO", "activation"
        mode_description = "Frequência de ativação de processos metabólicos"
    else:
        mode, mode_class = "ISOLAMENTO", "isolation"
        mode_description = "Frequência de isolamento - alta energia vibracional"
    
    # Modos vibracionais
    vibrational_modes = generate_vibrational_modes(atoms, resonance_freq_thz)
    
    # Energia
    energy_joules = PLANCK * resonance_freq_hz
    energy_ev = energy_joules / 1.602176634e-19
    energy_kj_mol = energy_joules * AVOGADRO / 1000
    
    return AnalysisResponse(
        id=str(uuid.uuid4()),
        name=request.name,
        frequencyTHz=resonance_freq_thz,
        frequencyHz=resonance_freq_hz,
        wavelengthUm=wavelength_um,
        geoFactor=geo_factor,
        phiFactor=phi_factor,
        mode=mode,
        modeClass=mode_class,
        modeDescription=mode_description,
        molecularMass=molecular_mass,
        reducedMass=reduced_mass,
        polarity=polarity,
        vibrationalModes=vibrational_modes,
        modesCount=modes_count,
        energy=EnergyResult(
            joules=energy_joules,
            electronVolts=energy_ev,
            kjPerMol=energy_kj_mol
        ),
        params={
            "atoms": atoms.dict(),
            "delta": params.delta,
            "intensity": params.intensity,
            "temperature": params.temperature
        },
        timestamp=int(datetime.now().timestamp() * 1000)
    )

def create_empty_response(name: str) -> AnalysisResponse:
    """Cria resposta vazia"""
    return AnalysisResponse(
        id=str(uuid.uuid4()),
        name=name or "Vazio",
        frequencyTHz=0,
        frequencyHz=0,
        wavelengthUm=0,
        geoFactor=0,
        phiFactor=PHI,
        mode="N/A",
        modeClass="empty",
        modeDescription="Adicione átomos para calcular",
        molecularMass=0,
        reducedMass=0,
        polarity=0,
        vibrationalModes=[],
        modesCount={"linear": 0, "nonLinear": 0, "total": 0},
        energy=EnergyResult(joules=0, electronVolts=0, kjPerMol=0),
        params={"atoms": {"C": 0, "H": 0, "O": 0, "N": 0, "P": 0, "S": 0}, "delta": 0, "intensity": 50, "temperature": 310},
        timestamp=int(datetime.now().timestamp() * 1000)
    )

# ═══════════════════════════════════════════════════════════════════════════
# FastAPI App
# ═══════════════════════════════════════════════════════════════════════════

app = FastAPI(
    title="Bio-Resonance Pro API",
    description="API para análise de frequência molecular em THz",
    version="4.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ═══════════════════════════════════════════════════════════════════════════
# ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════

@app.get("/", response_class=HTMLResponse)
async def root():
    """Página inicial"""
    return """
    <html>
        <head><title>Bio-Resonance Pro API</title></head>
        <body style="font-family: sans-serif; padding: 2rem;">
            <h1>🧬 Bio-Resonance Pro API v4.0</h1>
            <p>API para análise de frequência molecular em THz</p>
            <ul>
                <li><a href="/docs">Documentação Swagger</a></li>
                <li><a href="/redoc">Documentação ReDoc</a></li>
                <li><a href="/health">Health Check</a></li>
            </ul>
        </body>
    </html>
    """

@app.get("/health")
async def health():
    """Health check"""
    return {"status": "healthy", "version": "4.0.0", "engine": "python-fastapi"}

@app.get("/api/version")
async def version():
    """Retorna versão da API"""
    return {
        "version": "4.0.0",
        "engine": "python",
        "framework": "fastapi",
        "schema_version": 1
    }

@app.post("/api/analyze", response_model=AnalysisResponse)
async def analyze(request: AnalysisRequest):
    """
    Analisa frequência de ressonância molecular
    
    Retorna frequência em THz, energia vibracional, modo de ressonância
    e outras propriedades moleculares.
    """
    try:
        return compute_frequency(request)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analyze/batch")
async def analyze_batch(request: BatchAnalysisRequest):
    """Análise em lote de múltiplas amostras"""
    try:
        results = [compute_frequency(sample) for sample in request.samples]
        return {"results": results, "count": len(results)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/compare")
async def compare(request: ComparisonRequest):
    """Compara duas análises"""
    a, b = request.analysis_a, request.analysis_b
    
    freq_diff = abs(a.frequencyTHz - b.frequencyTHz)
    mass_diff = abs(a.molecularMass - b.molecularMass)
    polarity_diff = abs(a.polarity - b.polarity)
    
    max_freq = max(a.frequencyTHz, b.frequencyTHz)
    max_mass = max(a.molecularMass, b.molecularMass)
    
    freq_sim = max(0, 100 - (freq_diff / max_freq * 100)) if max_freq > 0 else 100
    mass_sim = max(0, 100 - (mass_diff / max_mass * 100)) if max_mass > 0 else 100
    pol_sim = max(0, 100 - polarity_diff * 100)
    
    overall = (freq_sim + mass_sim + pol_sim) / 3
    
    return {
        "samples": [a.name, b.name],
        "frequency": {
            "difference": freq_diff,
            "unit": "THz",
            "percentDiff": (freq_diff / max_freq * 100) if max_freq > 0 else 0,
            "similarity": freq_sim
        },
        "mass": {"difference": mass_diff, "unit": "g/mol", "similarity": mass_sim},
        "polarity": {"difference": polarity_diff, "similarity": pol_sim},
        "overallSimilarity": overall,
        "compatible": overall > 70,
        "resonanceMatch": freq_diff < 1
    }

@app.post("/api/stats")
async def stats(request: StatsRequest):
    """Calcula estatísticas para conjunto de análises"""
    analyses = request.analyses
    
    if not analyses:
        raise HTTPException(status_code=400, detail="Lista de análises vazia")
    
    frequencies = [a.frequencyTHz for a in analyses]
    masses = [a.molecularMass for a in analyses]
    polarities = [a.polarity for a in analyses]
    
    def mean(arr): return sum(arr) / len(arr)
    def variance(arr):
        m = mean(arr)
        return sum((x - m) ** 2 for x in arr) / len(arr)
    def std_dev(arr): return math.sqrt(variance(arr))
    
    modes = {}
    for a in analyses:
        modes[a.mode] = modes.get(a.mode, 0) + 1
    
    return {
        "count": len(analyses),
        "frequency": {
            "min": min(frequencies),
            "max": max(frequencies),
            "mean": mean(frequencies),
            "stdDev": std_dev(frequencies)
        },
        "mass": {
            "min": min(masses),
            "max": max(masses),
            "mean": mean(masses),
            "stdDev": std_dev(masses)
        },
        "polarity": {
            "min": min(polarities),
            "max": max(polarities),
            "mean": mean(polarities),
            "stdDev": std_dev(polarities)
        },
        "modes": modes
    }

@app.get("/api/presets")
async def presets():
    """Retorna moléculas predefinidas"""
    return {
        "glucose": {"name": "Glicose", "formula": "C₆H₁₂O₆", "atoms": {"C": 6, "H": 12, "O": 6, "N": 0, "P": 0, "S": 0}},
        "water": {"name": "Água", "formula": "H₂O", "atoms": {"C": 0, "H": 2, "O": 1, "N": 0, "P": 0, "S": 0}},
        "atp": {"name": "ATP", "formula": "C₁₀H₁₆N₅O₁₃P₃", "atoms": {"C": 10, "H": 16, "O": 13, "N": 5, "P": 3, "S": 0}},
        "caffeine": {"name": "Cafeína", "formula": "C₈H₁₀N₄O₂", "atoms": {"C": 8, "H": 10, "O": 2, "N": 4, "P": 0, "S": 0}},
        "ethanol": {"name": "Etanol", "formula": "C₂H₆O", "atoms": {"C": 2, "H": 6, "O": 1, "N": 0, "P": 0, "S": 0}},
        "aspirin": {"name": "Aspirina", "formula": "C₉H₈O₄", "atoms": {"C": 9, "H": 8, "O": 4, "N": 0, "P": 0, "S": 0}},
        "dopamine": {"name": "Dopamina", "formula": "C₈H₁₁NO₂", "atoms": {"C": 8, "H": 11, "O": 2, "N": 1, "P": 0, "S": 0}},
        "serotonin": {"name": "Serotonina", "formula": "C₁₀H₁₂N₂O", "atoms": {"C": 10, "H": 12, "O": 1, "N": 2, "P": 0, "S": 0}},
    }

# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)

/**
 * Bio-Resonance Pro v4.0 - Audio Sonification Module
 * Conversão de frequências moleculares em áudio audível
 * 
 * @module audio/sonification
 * @version 4.0.0
 */

// ═══════════════════════════════════════════════════════════════════════════
// CONSTANTES DE ÁUDIO
// ═══════════════════════════════════════════════════════════════════════════

const AUDIO_CONFIG = {
  MIN_FREQUENCY: 20,      // Hz (limite inferior audível)
  MAX_FREQUENCY: 2000,    // Hz (limite superior confortável)
  DEFAULT_VOLUME: 0.2,
  FADE_TIME: 0.05,        // segundos
  BINAURAL_OFFSET: 4,     // Hz (diferença binaural)
  THz_TO_AUDIBLE_SCALE: 100  // Fator de escala THz → Hz audível
};

// Notas musicais para mapeamento
const MUSICAL_NOTES = {
  'C': 261.63, 'C#': 277.18, 'D': 293.66, 'D#': 311.13,
  'E': 329.63, 'F': 349.23, 'F#': 369.99, 'G': 392.00,
  'G#': 415.30, 'A': 440.00, 'A#': 466.16, 'B': 493.88
};

// ═══════════════════════════════════════════════════════════════════════════
// CLASSE AUDIO ENGINE
// ═══════════════════════════════════════════════════════════════════════════

export class AudioEngine {
  constructor() {
    this.context = null;
    this.masterGain = null;
    this.oscillators = [];
    this.isPlaying = false;
    this.currentFrequency = 0;
    this.analyser = null;
    this.analyserData = null;
    this._animationFrame = null;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // INICIALIZAÇÃO
  // ─────────────────────────────────────────────────────────────────────────
  
  async init() {
    if (this.context) return this;
    
    try {
      this.context = new (window.AudioContext || window.webkitAudioContext)();
      
      // Master gain
      this.masterGain = this.context.createGain();
      this.masterGain.gain.value = AUDIO_CONFIG.DEFAULT_VOLUME;
      this.masterGain.connect(this.context.destination);
      
      // Analyser para visualização
      this.analyser = this.context.createAnalyser();
      this.analyser.fftSize = 2048;
      this.analyser.smoothingTimeConstant = 0.8;
      this.analyserData = new Uint8Array(this.analyser.frequencyBinCount);
      this.masterGain.connect(this.analyser);
      
      // Resumir contexto se suspenso
      if (this.context.state === 'suspended') {
        await this.context.resume();
      }
      
      return this;
    } catch (error) {
      console.error('Falha ao inicializar AudioEngine:', error);
      throw error;
    }
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // REPRODUÇÃO
  // ─────────────────────────────────────────────────────────────────────────
  
  /**
   * Reproduz frequência molecular como áudio
   * @param {Object} options - Opções de reprodução
   * @param {number} options.frequencyTHz - Frequência em THz
   * @param {string} options.waveform - Tipo de onda (sine, square, sawtooth, triangle)
   * @param {number} options.volume - Volume (0-1)
   * @param {boolean} options.binaural - Ativar batidas binaurais
   */
  async play(options) {
    const {
      frequencyTHz,
      waveform = 'sine',
      volume = AUDIO_CONFIG.DEFAULT_VOLUME,
      binaural = false
    } = options;
    
    await this.init();
    this.stop();
    
    // Converter THz para frequência audível
    const audibleFreq = this.thzToAudible(frequencyTHz);
    this.currentFrequency = audibleFreq;
    
    // Criar oscilador principal
    const mainOsc = this._createOscillator(audibleFreq, waveform);
    this.oscillators.push(mainOsc);
    
    // Batidas binaurais (opcional)
    if (binaural) {
      const binauralOsc = this._createOscillator(
        audibleFreq + AUDIO_CONFIG.BINAURAL_OFFSET,
        waveform
      );
      this.oscillators.push(binauralOsc);
    }
    
    // Ajustar volume
    this.setVolume(volume);
    
    // Iniciar
    const now = this.context.currentTime;
    for (const osc of this.oscillators) {
      osc.oscillator.start(now);
    }
    
    this.isPlaying = true;
    this._startAnalysis();
    
    return this;
  }
  
  /**
   * Reproduz sequência de frequências (arpejo molecular)
   * @param {Array} frequencies - Lista de frequências THz
   * @param {Object} options - Opções
   */
  async playSequence(frequencies, options = {}) {
    const {
      waveform = 'sine',
      noteLength = 0.3,
      volume = AUDIO_CONFIG.DEFAULT_VOLUME
    } = options;
    
    await this.init();
    this.stop();
    
    const now = this.context.currentTime;
    
    for (let i = 0; i < frequencies.length; i++) {
      const audibleFreq = this.thzToAudible(frequencies[i]);
      const startTime = now + i * noteLength;
      const endTime = startTime + noteLength * 0.9;
      
      const osc = this.context.createOscillator();
      const gain = this.context.createGain();
      
      osc.type = waveform;
      osc.frequency.value = audibleFreq;
      
      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(volume, startTime + 0.02);
      gain.gain.linearRampToValueAtTime(0, endTime);
      
      osc.connect(gain);
      gain.connect(this.masterGain);
      
      osc.start(startTime);
      osc.stop(endTime + 0.1);
    }
    
    return this;
  }
  
  /**
   * Reproduz harmónicos da frequência
   * @param {number} frequencyTHz - Frequência base em THz
   * @param {Object} options - Opções
   */
  async playHarmonics(frequencyTHz, options = {}) {
    const {
      harmonicCount = 5,
      waveform = 'sine',
      volume = AUDIO_CONFIG.DEFAULT_VOLUME
    } = options;
    
    await this.init();
    this.stop();
    
    const baseFreq = this.thzToAudible(frequencyTHz);
    
    for (let h = 1; h <= harmonicCount; h++) {
      const freq = baseFreq * h;
      if (freq > AUDIO_CONFIG.MAX_FREQUENCY) break;
      
      const harmonicVolume = volume / (h * 1.5); // Decaimento natural
      const osc = this._createOscillator(freq, waveform, harmonicVolume);
      this.oscillators.push(osc);
    }
    
    const now = this.context.currentTime;
    for (const osc of this.oscillators) {
      osc.oscillator.start(now);
    }
    
    this.isPlaying = true;
    this._startAnalysis();
    
    return this;
  }
  
  /**
   * Para toda reprodução
   */
  stop() {
    const now = this.context?.currentTime || 0;
    
    for (const { oscillator, gain } of this.oscillators) {
      try {
        gain.gain.linearRampToValueAtTime(0, now + AUDIO_CONFIG.FADE_TIME);
        oscillator.stop(now + AUDIO_CONFIG.FADE_TIME + 0.1);
      } catch (e) {
        // Oscilador já parado
      }
    }
    
    this.oscillators = [];
    this.isPlaying = false;
    this._stopAnalysis();
    
    return this;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // CONTROLES
  // ─────────────────────────────────────────────────────────────────────────
  
  setVolume(volume) {
    if (this.masterGain) {
      this.masterGain.gain.linearRampToValueAtTime(
        Math.max(0, Math.min(1, volume)),
        this.context.currentTime + 0.05
      );
    }
    return this;
  }
  
  setFrequency(frequencyTHz) {
    const audibleFreq = this.thzToAudible(frequencyTHz);
    this.currentFrequency = audibleFreq;
    
    for (const { oscillator } of this.oscillators) {
      oscillator.frequency.linearRampToValueAtTime(
        audibleFreq,
        this.context.currentTime + 0.1
      );
    }
    
    return this;
  }
  
  setWaveform(waveform) {
    for (const { oscillator } of this.oscillators) {
      oscillator.type = waveform;
    }
    return this;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // CONVERSÕES
  // ─────────────────────────────────────────────────────────────────────────
  
  /**
   * Converte THz para frequência audível
   * Usa escala logarítmica para mapeamento musical
   */
  thzToAudible(thz) {
    // Mapeamento logarítmico para range audível
    const minThz = 0.1;
    const maxThz = 100;
    
    const normalizedLog = Math.log10(Math.max(minThz, thz) / minThz) / 
                          Math.log10(maxThz / minThz);
    
    const freq = AUDIO_CONFIG.MIN_FREQUENCY + 
                 normalizedLog * (AUDIO_CONFIG.MAX_FREQUENCY - AUDIO_CONFIG.MIN_FREQUENCY);
    
    return Math.max(AUDIO_CONFIG.MIN_FREQUENCY, Math.min(AUDIO_CONFIG.MAX_FREQUENCY, freq));
  }
  
  /**
   * Retorna a nota musical mais próxima
   */
  frequencyToNote(freq) {
    const noteNames = Object.keys(MUSICAL_NOTES);
    const noteFreqs = Object.values(MUSICAL_NOTES);
    
    let closestNote = 'A';
    let minDiff = Infinity;
    let octave = 4;
    
    // Normalizar para oitava 4
    while (freq > noteFreqs[noteFreqs.length - 1] * 1.5) {
      freq /= 2;
      octave++;
    }
    while (freq < noteFreqs[0] / 1.5) {
      freq *= 2;
      octave--;
    }
    
    for (let i = 0; i < noteFreqs.length; i++) {
      const diff = Math.abs(freq - noteFreqs[i]);
      if (diff < minDiff) {
        minDiff = diff;
        closestNote = noteNames[i];
      }
    }
    
    return `${closestNote}${octave}`;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // ANÁLISE EM TEMPO REAL
  // ─────────────────────────────────────────────────────────────────────────
  
  getFrequencyData() {
    if (!this.analyser) return new Uint8Array(0);
    this.analyser.getByteFrequencyData(this.analyserData);
    return this.analyserData;
  }
  
  getTimeDomainData() {
    if (!this.analyser) return new Uint8Array(0);
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteTimeDomainData(data);
    return data;
  }
  
  onAnalysis(callback) {
    this._analysisCallback = callback;
    return this;
  }
  
  _startAnalysis() {
    const analyze = () => {
      if (!this.isPlaying) return;
      
      if (this._analysisCallback) {
        this._analysisCallback({
          frequency: this.getFrequencyData(),
          timeDomain: this.getTimeDomainData(),
          currentFrequency: this.currentFrequency,
          isPlaying: this.isPlaying
        });
      }
      
      this._animationFrame = requestAnimationFrame(analyze);
    };
    
    analyze();
  }
  
  _stopAnalysis() {
    if (this._animationFrame) {
      cancelAnimationFrame(this._animationFrame);
      this._animationFrame = null;
    }
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // HELPERS PRIVADOS
  // ─────────────────────────────────────────────────────────────────────────
  
  _createOscillator(frequency, waveform, volume = null) {
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    
    oscillator.type = waveform;
    oscillator.frequency.value = frequency;
    
    if (volume !== null) {
      gain.gain.value = volume;
    }
    
    oscillator.connect(gain);
    gain.connect(this.masterGain);
    
    return { oscillator, gain };
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // CLEANUP
  // ─────────────────────────────────────────────────────────────────────────
  
  dispose() {
    this.stop();
    
    if (this.context) {
      this.context.close();
      this.context = null;
    }
    
    this.masterGain = null;
    this.analyser = null;
    this.analyserData = null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GERADOR DE TONS ESPECIAIS
// ═══════════════════════════════════════════════════════════════════════════

export class ToneGenerator {
  constructor(audioEngine) {
    this.engine = audioEngine;
  }
  
  /**
   * Gera tom de relaxamento baseado em frequências de Schumann
   */
  async schumannResonance(options = {}) {
    await this.engine.init();
    
    const schumannFreqs = [7.83, 14.3, 20.8, 27.3, 33.8]; // Hz
    
    for (const freq of schumannFreqs) {
      const osc = this.engine._createOscillator(freq, 'sine', 0.1);
      this.engine.oscillators.push(osc);
    }
    
    const now = this.engine.context.currentTime;
    for (const { oscillator } of this.engine.oscillators) {
      oscillator.start(now);
    }
    
    this.engine.isPlaying = true;
  }
  
  /**
   * Gera batidas binaurais para frequência alvo
   */
  async binauralBeats(targetFreq, options = {}) {
    const { baseFreq = 200, volume = 0.3 } = options;
    
    await this.engine.init();
    this.engine.stop();
    
    const leftOsc = this.engine._createOscillator(baseFreq, 'sine', volume);
    const rightOsc = this.engine._createOscillator(baseFreq + targetFreq, 'sine', volume);
    
    this.engine.oscillators.push(leftOsc, rightOsc);
    
    const now = this.engine.context.currentTime;
    leftOsc.oscillator.start(now);
    rightOsc.oscillator.start(now);
    
    this.engine.isPlaying = true;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// INSTÂNCIA SINGLETON
// ═══════════════════════════════════════════════════════════════════════════

export const audioEngine = new AudioEngine();
export const toneGenerator = new ToneGenerator(audioEngine);

export default audioEngine;

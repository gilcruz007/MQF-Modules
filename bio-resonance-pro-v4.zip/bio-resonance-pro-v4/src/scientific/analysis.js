/**
 * Bio-Resonance Pro v4.0 - Scientific Analysis Module
 * FFT conceitual, modos vibracionais e análise avançada
 * 
 * @module scientific/analysis
 * @version 4.0.0
 */

// ═══════════════════════════════════════════════════════════════════════════
// FFT (FAST FOURIER TRANSFORM) CONCEITUAL
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Implementação simplificada de FFT para análise conceitual
 * Baseada no algoritmo Cooley-Tukey
 */
export class FFT {
  constructor(size = 1024) {
    this.size = size;
    this.real = new Float64Array(size);
    this.imag = new Float64Array(size);
    this.spectrum = new Float64Array(size / 2);
    this.phase = new Float64Array(size / 2);
    
    // Pré-computar fatores de rotação (twiddle factors)
    this._twiddleReal = new Float64Array(size / 2);
    this._twiddleImag = new Float64Array(size / 2);
    
    for (let i = 0; i < size / 2; i++) {
      const angle = -2 * Math.PI * i / size;
      this._twiddleReal[i] = Math.cos(angle);
      this._twiddleImag[i] = Math.sin(angle);
    }
  }
  
  /**
   * Realiza FFT em sinal de entrada
   * @param {Float64Array} signal - Sinal de entrada
   * @returns {Object} { spectrum, phase, frequencies }
   */
  forward(signal) {
    const n = this.size;
    
    // Copiar sinal para arrays de trabalho
    for (let i = 0; i < n; i++) {
      this.real[i] = signal[i] || 0;
      this.imag[i] = 0;
    }
    
    // Bit-reversal permutation
    this._bitReverse(this.real, n);
    this._bitReverse(this.imag, n);
    
    // FFT Cooley-Tukey
    for (let len = 2; len <= n; len *= 2) {
      const halfLen = len / 2;
      const step = n / len;
      
      for (let i = 0; i < n; i += len) {
        for (let j = 0; j < halfLen; j++) {
          const twiddleIdx = j * step;
          const tR = this._twiddleReal[twiddleIdx];
          const tI = this._twiddleImag[twiddleIdx];
          
          const evenIdx = i + j;
          const oddIdx = i + j + halfLen;
          
          const eR = this.real[evenIdx];
          const eI = this.imag[evenIdx];
          const oR = this.real[oddIdx] * tR - this.imag[oddIdx] * tI;
          const oI = this.real[oddIdx] * tI + this.imag[oddIdx] * tR;
          
          this.real[evenIdx] = eR + oR;
          this.imag[evenIdx] = eI + oI;
          this.real[oddIdx] = eR - oR;
          this.imag[oddIdx] = eI - oI;
        }
      }
    }
    
    // Calcular espectro de magnitude e fase
    for (let i = 0; i < n / 2; i++) {
      this.spectrum[i] = Math.sqrt(this.real[i] ** 2 + this.imag[i] ** 2) / n;
      this.phase[i] = Math.atan2(this.imag[i], this.real[i]);
    }
    
    return {
      spectrum: this.spectrum,
      phase: this.phase,
      real: this.real,
      imag: this.imag
    };
  }
  
  /**
   * Gera frequências correspondentes aos bins
   * @param {number} sampleRate - Taxa de amostragem
   */
  getFrequencies(sampleRate) {
    const frequencies = new Float64Array(this.size / 2);
    for (let i = 0; i < this.size / 2; i++) {
      frequencies[i] = i * sampleRate / this.size;
    }
    return frequencies;
  }
  
  /**
   * Encontra picos no espectro
   * @param {number} threshold - Limiar relativo ao máximo (0-1)
   * @param {number} sampleRate - Taxa de amostragem
   */
  findPeaks(threshold = 0.1, sampleRate = 1) {
    const peaks = [];
    const maxMag = Math.max(...this.spectrum);
    const absThreshold = threshold * maxMag;
    
    for (let i = 1; i < this.spectrum.length - 1; i++) {
      if (this.spectrum[i] > absThreshold &&
          this.spectrum[i] > this.spectrum[i - 1] &&
          this.spectrum[i] > this.spectrum[i + 1]) {
        peaks.push({
          bin: i,
          frequency: i * sampleRate / this.size,
          magnitude: this.spectrum[i],
          phase: this.phase[i]
        });
      }
    }
    
    return peaks.sort((a, b) => b.magnitude - a.magnitude);
  }
  
  _bitReverse(arr, n) {
    let j = 0;
    for (let i = 0; i < n - 1; i++) {
      if (i < j) {
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      let k = n >> 1;
      while (k <= j) {
        j -= k;
        k >>= 1;
      }
      j += k;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// GERADOR DE ESPECTRO VIBRACIONAL
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Gera espectro vibracional simulado para molécula
 * @param {Object} analysisResult - Resultado da análise molecular
 * @param {Object} options - Opções de geração
 */
export function generateVibrationalSpectrum(analysisResult, options = {}) {
  const {
    resolution = 512,
    minFreq = 0.1,
    maxFreq = 100,
    lineWidth = 0.5
  } = options;
  
  const spectrum = new Float64Array(resolution);
  const frequencies = new Float64Array(resolution);
  
  // Gerar eixo de frequências (escala logarítmica)
  for (let i = 0; i < resolution; i++) {
    const t = i / (resolution - 1);
    frequencies[i] = minFreq * Math.pow(maxFreq / minFreq, t);
  }
  
  // Adicionar picos para cada modo vibracional
  const modes = analysisResult.vibrationalModes || [];
  
  for (const mode of modes) {
    for (let i = 0; i < resolution; i++) {
      // Perfil Lorentziano para cada pico
      const x = frequencies[i];
      const x0 = mode.frequency;
      const gamma = lineWidth;
      const intensity = mode.intensity || 1;
      
      const lorentzian = intensity * (gamma ** 2) / 
                         ((x - x0) ** 2 + gamma ** 2);
      
      spectrum[i] += lorentzian;
    }
  }
  
  // Adicionar frequência fundamental
  const fundamentalFreq = analysisResult.frequencyTHz;
  for (let i = 0; i < resolution; i++) {
    const x = frequencies[i];
    const lorentzian = 2 * (lineWidth ** 2) / 
                       ((x - fundamentalFreq) ** 2 + lineWidth ** 2);
    spectrum[i] += lorentzian;
  }
  
  // Normalizar
  const maxVal = Math.max(...spectrum);
  if (maxVal > 0) {
    for (let i = 0; i < resolution; i++) {
      spectrum[i] /= maxVal;
    }
  }
  
  return {
    frequencies,
    spectrum,
    peaks: identifyPeaks(frequencies, spectrum),
    metadata: {
      resolution,
      freqRange: [minFreq, maxFreq],
      modesCount: modes.length,
      fundamental: fundamentalFreq
    }
  };
}

/**
 * Identifica picos no espectro
 */
function identifyPeaks(frequencies, spectrum, threshold = 0.05) {
  const peaks = [];
  
  for (let i = 1; i < spectrum.length - 1; i++) {
    if (spectrum[i] > threshold &&
        spectrum[i] > spectrum[i - 1] &&
        spectrum[i] > spectrum[i + 1]) {
      peaks.push({
        index: i,
        frequency: frequencies[i],
        intensity: spectrum[i],
        assignment: assignPeak(frequencies[i])
      });
    }
  }
  
  return peaks.sort((a, b) => b.intensity - a.intensity).slice(0, 20);
}

/**
 * Atribui tipo de vibração ao pico baseado na frequência
 */
function assignPeak(freq) {
  if (freq < 5) return 'Torção/Deformação de baixa energia';
  if (freq < 15) return 'Flexão angular';
  if (freq < 30) return 'Estiramento C-C/C-N';
  if (freq < 50) return 'Estiramento C-O/C=C';
  if (freq < 80) return 'Estiramento C-H/N-H';
  return 'Estiramento O-H/Harmónicos';
}

// ═══════════════════════════════════════════════════════════════════════════
// ANÁLISE ESTATÍSTICA
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Calcula estatísticas descritivas para conjunto de análises
 * @param {Array} analyses - Lista de resultados de análise
 */
export function calculateStatistics(analyses) {
  if (!analyses || analyses.length === 0) {
    return null;
  }
  
  const frequencies = analyses.map(a => a.frequencyTHz);
  const masses = analyses.map(a => a.molecularMass);
  const polarities = analyses.map(a => a.polarity);
  
  return {
    count: analyses.length,
    frequency: {
      min: Math.min(...frequencies),
      max: Math.max(...frequencies),
      mean: mean(frequencies),
      median: median(frequencies),
      stdDev: standardDeviation(frequencies),
      variance: variance(frequencies),
      range: Math.max(...frequencies) - Math.min(...frequencies)
    },
    mass: {
      min: Math.min(...masses),
      max: Math.max(...masses),
      mean: mean(masses),
      median: median(masses),
      stdDev: standardDeviation(masses)
    },
    polarity: {
      min: Math.min(...polarities),
      max: Math.max(...polarities),
      mean: mean(polarities),
      stdDev: standardDeviation(polarities)
    },
    correlations: {
      freqMass: pearsonCorrelation(frequencies, masses),
      freqPolarity: pearsonCorrelation(frequencies, polarities),
      massPolarity: pearsonCorrelation(masses, polarities)
    },
    modes: countModes(analyses)
  };
}

function mean(arr) {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function median(arr) {
  const sorted = [...arr].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

function variance(arr) {
  const m = mean(arr);
  return arr.reduce((sum, x) => sum + (x - m) ** 2, 0) / arr.length;
}

function standardDeviation(arr) {
  return Math.sqrt(variance(arr));
}

function pearsonCorrelation(x, y) {
  const n = x.length;
  const meanX = mean(x);
  const meanY = mean(y);
  
  let numerator = 0;
  let denomX = 0;
  let denomY = 0;
  
  for (let i = 0; i < n; i++) {
    const dx = x[i] - meanX;
    const dy = y[i] - meanY;
    numerator += dx * dy;
    denomX += dx ** 2;
    denomY += dy ** 2;
  }
  
  const denom = Math.sqrt(denomX * denomY);
  return denom === 0 ? 0 : numerator / denom;
}

function countModes(analyses) {
  const modes = {};
  for (const a of analyses) {
    modes[a.mode] = (modes[a.mode] || 0) + 1;
  }
  return modes;
}

// ═══════════════════════════════════════════════════════════════════════════
// CLUSTERING AVANÇADO
// ═══════════════════════════════════════════════════════════════════════════

/**
 * K-Means clustering para análises
 * @param {Array} analyses - Lista de análises
 * @param {number} k - Número de clusters
 * @param {number} maxIterations - Máximo de iterações
 */
export function kMeansClustering(analyses, k = 3, maxIterations = 100) {
  if (analyses.length < k) {
    return { clusters: [{ members: analyses }], centroids: [] };
  }
  
  // Normalizar features
  const features = analyses.map(a => [
    a.frequencyTHz,
    a.molecularMass / 100,
    a.polarity
  ]);
  
  // Inicializar centroides aleatoriamente
  let centroids = [];
  const usedIndices = new Set();
  while (centroids.length < k) {
    const idx = Math.floor(Math.random() * features.length);
    if (!usedIndices.has(idx)) {
      centroids.push([...features[idx]]);
      usedIndices.add(idx);
    }
  }
  
  let assignments = new Array(analyses.length).fill(0);
  let iterations = 0;
  let changed = true;
  
  while (changed && iterations < maxIterations) {
    changed = false;
    iterations++;
    
    // Atribuir pontos ao centroide mais próximo
    for (let i = 0; i < features.length; i++) {
      let minDist = Infinity;
      let minCluster = 0;
      
      for (let c = 0; c < k; c++) {
        const dist = euclideanDistance(features[i], centroids[c]);
        if (dist < minDist) {
          minDist = dist;
          minCluster = c;
        }
      }
      
      if (assignments[i] !== minCluster) {
        assignments[i] = minCluster;
        changed = true;
      }
    }
    
    // Recalcular centroides
    for (let c = 0; c < k; c++) {
      const clusterPoints = features.filter((_, i) => assignments[i] === c);
      if (clusterPoints.length > 0) {
        centroids[c] = [
          mean(clusterPoints.map(p => p[0])),
          mean(clusterPoints.map(p => p[1])),
          mean(clusterPoints.map(p => p[2]))
        ];
      }
    }
  }
  
  // Construir resultado
  const clusters = [];
  for (let c = 0; c < k; c++) {
    const members = analyses.filter((_, i) => assignments[i] === c);
    if (members.length > 0) {
      clusters.push({
        id: c + 1,
        members,
        centroid: {
          frequencyTHz: centroids[c][0],
          molecularMass: centroids[c][1] * 100,
          polarity: centroids[c][2]
        },
        size: members.length
      });
    }
  }
  
  return {
    clusters,
    centroids,
    iterations,
    inertia: calculateInertia(features, assignments, centroids)
  };
}

function euclideanDistance(a, b) {
  return Math.sqrt(a.reduce((sum, val, i) => sum + (val - b[i]) ** 2, 0));
}

function calculateInertia(features, assignments, centroids) {
  return features.reduce((sum, f, i) => 
    sum + euclideanDistance(f, centroids[assignments[i]]) ** 2, 0);
}

// ═══════════════════════════════════════════════════════════════════════════
// ANÁLISE DE SIMILARIDADE
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Calcula matriz de similaridade entre análises
 * @param {Array} analyses - Lista de análises
 */
export function calculateSimilarityMatrix(analyses) {
  const n = analyses.length;
  const matrix = Array(n).fill(null).map(() => Array(n).fill(0));
  
  for (let i = 0; i < n; i++) {
    for (let j = i; j < n; j++) {
      if (i === j) {
        matrix[i][j] = 1;
      } else {
        const similarity = calculatePairSimilarity(analyses[i], analyses[j]);
        matrix[i][j] = similarity;
        matrix[j][i] = similarity;
      }
    }
  }
  
  return {
    matrix,
    labels: analyses.map(a => a.name),
    mostSimilar: findMostSimilarPairs(analyses, matrix),
    mostDifferent: findMostDifferentPairs(analyses, matrix)
  };
}

function calculatePairSimilarity(a, b) {
  const freqSim = 1 - Math.abs(a.frequencyTHz - b.frequencyTHz) / 
                     Math.max(a.frequencyTHz, b.frequencyTHz);
  const massSim = 1 - Math.abs(a.molecularMass - b.molecularMass) / 
                     Math.max(a.molecularMass, b.molecularMass);
  const polSim = 1 - Math.abs(a.polarity - b.polarity);
  
  return (freqSim + massSim + polSim) / 3;
}

function findMostSimilarPairs(analyses, matrix) {
  const pairs = [];
  for (let i = 0; i < matrix.length; i++) {
    for (let j = i + 1; j < matrix.length; j++) {
      pairs.push({
        a: analyses[i].name,
        b: analyses[j].name,
        similarity: matrix[i][j]
      });
    }
  }
  return pairs.sort((a, b) => b.similarity - a.similarity).slice(0, 5);
}

function findMostDifferentPairs(analyses, matrix) {
  const pairs = [];
  for (let i = 0; i < matrix.length; i++) {
    for (let j = i + 1; j < matrix.length; j++) {
      pairs.push({
        a: analyses[i].name,
        b: analyses[j].name,
        similarity: matrix[i][j]
      });
    }
  }
  return pairs.sort((a, b) => a.similarity - b.similarity).slice(0, 5);
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTAÇÃO PDF CIENTÍFICA
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Gera dados para relatório PDF científico
 * @param {Object} analysis - Resultado da análise
 * @param {Array} history - Histórico de análises
 * @param {Object} options - Opções de exportação
 */
export function generateScientificReport(analysis, history = [], options = {}) {
  const {
    includeStats = true,
    includeSpectrum = true,
    includeClustering = true,
    language = 'pt'
  } = options;
  
  const report = {
    meta: {
      title: `Relatório de Análise Molecular - ${analysis.name}`,
      date: new Date().toISOString(),
      version: '4.0.0',
      software: 'Bio-Resonance Pro'
    },
    
    sample: {
      name: analysis.name,
      formula: formatFormula(analysis.params.atoms),
      molecularMass: analysis.molecularMass,
      composition: analysis.params.atoms
    },
    
    results: {
      frequency: {
        value: analysis.frequencyTHz,
        unit: 'THz',
        wavelength: analysis.wavelengthUm,
        wavelengthUnit: 'μm'
      },
      energy: analysis.energy,
      mode: analysis.mode,
      modeDescription: analysis.modeDescription,
      geoFactor: analysis.geoFactor,
      phiFactor: analysis.phiFactor,
      polarity: analysis.polarity
    },
    
    parameters: {
      delta: analysis.params.delta,
      intensity: analysis.params.intensity,
      temperature: analysis.params.temperature,
      engine: analysis.engine
    },
    
    vibrationalModes: analysis.vibrationalModes
  };
  
  if (includeSpectrum) {
    report.spectrum = generateVibrationalSpectrum(analysis);
  }
  
  if (includeStats && history.length > 1) {
    report.statistics = calculateStatistics(history);
  }
  
  if (includeClustering && history.length > 3) {
    report.clustering = kMeansClustering(history, Math.min(3, history.length));
  }
  
  return report;
}

function formatFormula(atoms) {
  const subscripts = '₀₁₂₃₄₅₆₇₈₉';
  const toSubscript = n => n.toString().split('').map(d => subscripts[d]).join('');
  
  let formula = '';
  for (const atom of ['C', 'H', 'O', 'N', 'P', 'S']) {
    if (atoms[atom] > 0) {
      formula += atom + (atoms[atom] > 1 ? toSubscript(atoms[atom]) : '');
    }
  }
  return formula || '---';
}

/**
 * Converte relatório para HTML formatado para impressão
 */
export function reportToHTML(report) {
  return `
<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <title>${report.meta.title}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Times New Roman', serif; font-size: 11pt; line-height: 1.5; padding: 2cm; }
    h1 { font-size: 16pt; margin-bottom: 1cm; text-align: center; }
    h2 { font-size: 13pt; margin: 0.5cm 0 0.3cm; border-bottom: 1px solid #333; }
    h3 { font-size: 11pt; margin: 0.3cm 0 0.2cm; }
    table { width: 100%; border-collapse: collapse; margin: 0.3cm 0; }
    th, td { border: 1px solid #666; padding: 4px 8px; text-align: left; }
    th { background: #f0f0f0; }
    .header { display: flex; justify-content: space-between; margin-bottom: 0.5cm; }
    .value { font-weight: bold; color: #0066cc; }
    .section { margin-bottom: 0.5cm; }
    @media print { body { padding: 1cm; } }
  </style>
</head>
<body>
  <div class="header">
    <span>Bio-Resonance Pro v${report.meta.version}</span>
    <span>${new Date(report.meta.date).toLocaleDateString('pt-PT')}</span>
  </div>
  
  <h1>${report.meta.title}</h1>
  
  <div class="section">
    <h2>1. Identificação da Amostra</h2>
    <table>
      <tr><td>Nome</td><td class="value">${report.sample.name}</td></tr>
      <tr><td>Fórmula Molecular</td><td class="value">${report.sample.formula}</td></tr>
      <tr><td>Massa Molecular</td><td class="value">${report.sample.molecularMass.toFixed(3)} g/mol</td></tr>
    </table>
  </div>
  
  <div class="section">
    <h2>2. Resultados da Análise</h2>
    <table>
      <tr><td>Frequência de Ressonância</td><td class="value">${report.results.frequency.value.toFixed(6)} THz</td></tr>
      <tr><td>Comprimento de Onda</td><td class="value">${report.results.frequency.wavelength.toFixed(3)} μm</td></tr>
      <tr><td>Modo de Ressonância</td><td class="value">${report.results.mode}</td></tr>
      <tr><td>Índice de Polaridade</td><td class="value">${report.results.polarity.toFixed(4)}</td></tr>
      <tr><td>Fator Geométrico (φ)</td><td class="value">${report.results.geoFactor.toFixed(6)}</td></tr>
    </table>
    
    <h3>2.1 Energia Vibracional</h3>
    <table>
      <tr><td>Energia (J)</td><td class="value">${report.results.energy.joules.toExponential(4)}</td></tr>
      <tr><td>Energia (eV)</td><td class="value">${report.results.energy.electronVolts.toExponential(4)}</td></tr>
      <tr><td>Energia (kJ/mol)</td><td class="value">${report.results.energy.kjPerMol.toFixed(4)}</td></tr>
    </table>
  </div>
  
  <div class="section">
    <h2>3. Parâmetros Experimentais</h2>
    <table>
      <tr><td>Desvio Estrutural (Δ)</td><td>${report.parameters.delta.toFixed(4)}</td></tr>
      <tr><td>Intensidade de Campo</td><td>${report.parameters.intensity}%</td></tr>
      <tr><td>Temperatura</td><td>${report.parameters.temperature} K</td></tr>
      <tr><td>Motor de Cálculo</td><td>${report.parameters.engine.toUpperCase()}</td></tr>
    </table>
  </div>
  
  ${report.vibrationalModes && report.vibrationalModes.length > 0 ? `
  <div class="section">
    <h2>4. Modos Vibracionais</h2>
    <table>
      <tr><th>Tipo</th><th>Frequência (THz)</th><th>Intensidade</th></tr>
      ${report.vibrationalModes.slice(0, 10).map(m => `
        <tr>
          <td>${m.label}</td>
          <td>${m.frequency.toFixed(4)}</td>
          <td>${(m.intensity * 100).toFixed(1)}%</td>
        </tr>
      `).join('')}
    </table>
  </div>
  ` : ''}
  
  <div class="section" style="margin-top: 1cm; font-size: 9pt; color: #666;">
    <p><strong>Nota:</strong> Este relatório foi gerado por Bio-Resonance Pro v${report.meta.version}. 
    Os resultados são baseados em modelos computacionais e devem ser interpretados com cautela científica.
    Para fins educacionais e de pesquisa.</p>
  </div>
</body>
</html>
  `;
}

export default {
  FFT,
  generateVibrationalSpectrum,
  calculateStatistics,
  kMeansClustering,
  calculateSimilarityMatrix,
  generateScientificReport,
  reportToHTML
};

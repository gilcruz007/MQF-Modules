/**
 * Bio-Resonance Pro v4.0 - State Management Module
 * Gestão de estado reativa com padrão Observer
 * 
 * @module state/store
 * @version 4.0.0
 */

// ═══════════════════════════════════════════════════════════════════════════
// ESTADO INICIAL
// ═══════════════════════════════════════════════════════════════════════════

const initialState = {
  // Configuração do motor de cálculo
  engine: 'js', // 'js' | 'wasm' | 'api'
  wasmReady: false,
  apiUrl: '/api/analyze',
  apiAvailable: false,
  
  // Composição atómica atual
  atoms: {
    C: 6, H: 12, O: 6, N: 0, P: 0, S: 0
  },
  sampleName: 'Glicose',
  
  // Parâmetros de análise
  params: {
    delta: 0.2,
    intensity: 50,
    temperature: 310
  },
  
  // Resultado atual
  currentResult: null,
  
  // Histórico de análises
  history: [],
  maxHistorySize: 50,
  
  // Estatísticas
  stats: {
    totalAnalyses: 0,
    avgFrequency: 0,
    lastAnalysisTime: null
  },
  
  // Estado da UI
  ui: {
    activeTab: 'analysis',
    isAnalyzing: false,
    isPlaying: false,
    showAdvanced: false,
    theme: 'dark',
    showFFT: false,
    showModes: true
  },
  
  // Configurações de áudio
  audio: {
    enabled: false,
    waveform: 'sine',
    volume: 0.2,
    baseMultiplier: 100 // THz para Hz audível
  },
  
  // Configurações de exportação
  export: {
    format: 'pdf',
    includeCharts: true,
    includeHistory: true
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// CLASSE STORE - GESTÃO DE ESTADO REATIVA
// ═══════════════════════════════════════════════════════════════════════════

class Store {
  constructor(initialState) {
    this._state = this._deepClone(initialState);
    this._listeners = new Map();
    this._middleware = [];
    this._history = [];
    this._historyIndex = -1;
    this._maxUndoSteps = 20;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // GETTERS
  // ─────────────────────────────────────────────────────────────────────────
  
  get state() {
    return this._deepFreeze(this._deepClone(this._state));
  }
  
  get(path) {
    return this._getByPath(this._state, path);
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // SETTERS COM NOTIFICAÇÃO
  // ─────────────────────────────────────────────────────────────────────────
  
  set(path, value) {
    const prevState = this._deepClone(this._state);
    
    // Aplicar middleware
    let finalValue = value;
    for (const mw of this._middleware) {
      finalValue = mw(path, finalValue, prevState);
    }
    
    // Atualizar estado
    this._setByPath(this._state, path, finalValue);
    
    // Guardar histórico para undo
    this._pushHistory(prevState);
    
    // Notificar listeners
    this._notify(path, finalValue, prevState);
    
    return this;
  }
  
  update(path, updater) {
    const currentValue = this.get(path);
    const newValue = updater(currentValue);
    return this.set(path, newValue);
  }
  
  merge(partialState) {
    const prevState = this._deepClone(this._state);
    this._state = this._deepMerge(this._state, partialState);
    this._pushHistory(prevState);
    this._notify('*', this._state, prevState);
    return this;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // SUBSCRIPTIONS
  // ─────────────────────────────────────────────────────────────────────────
  
  subscribe(path, callback) {
    if (!this._listeners.has(path)) {
      this._listeners.set(path, new Set());
    }
    this._listeners.get(path).add(callback);
    
    // Retorna função de unsubscribe
    return () => {
      this._listeners.get(path)?.delete(callback);
    };
  }
  
  subscribeAll(callback) {
    return this.subscribe('*', callback);
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // UNDO/REDO
  // ─────────────────────────────────────────────────────────────────────────
  
  undo() {
    if (this._historyIndex > 0) {
      this._historyIndex--;
      const prevState = this._state;
      this._state = this._deepClone(this._history[this._historyIndex]);
      this._notify('*', this._state, prevState);
    }
    return this;
  }
  
  redo() {
    if (this._historyIndex < this._history.length - 1) {
      this._historyIndex++;
      const prevState = this._state;
      this._state = this._deepClone(this._history[this._historyIndex]);
      this._notify('*', this._state, prevState);
    }
    return this;
  }
  
  canUndo() {
    return this._historyIndex > 0;
  }
  
  canRedo() {
    return this._historyIndex < this._history.length - 1;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // MIDDLEWARE
  // ─────────────────────────────────────────────────────────────────────────
  
  use(middleware) {
    this._middleware.push(middleware);
    return this;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // PERSISTÊNCIA
  // ─────────────────────────────────────────────────────────────────────────
  
  persist(key = 'bio-resonance-state') {
    try {
      const serialized = JSON.stringify(this._state);
      localStorage.setItem(key, serialized);
    } catch (e) {
      console.warn('Falha ao persistir estado:', e);
    }
    return this;
  }
  
  hydrate(key = 'bio-resonance-state') {
    try {
      const serialized = localStorage.getItem(key);
      if (serialized) {
        const savedState = JSON.parse(serialized);
        this._state = this._deepMerge(this._state, savedState);
        this._notify('*', this._state, null);
      }
    } catch (e) {
      console.warn('Falha ao recuperar estado:', e);
    }
    return this;
  }
  
  reset() {
    const prevState = this._state;
    this._state = this._deepClone(initialState);
    this._history = [];
    this._historyIndex = -1;
    this._notify('*', this._state, prevState);
    return this;
  }
  
  // ─────────────────────────────────────────────────────────────────────────
  // MÉTODOS PRIVADOS
  // ─────────────────────────────────────────────────────────────────────────
  
  _notify(path, value, prevState) {
    // Notificar listeners específicos
    if (this._listeners.has(path)) {
      for (const callback of this._listeners.get(path)) {
        try {
          callback(value, prevState);
        } catch (e) {
          console.error('Erro em listener:', e);
        }
      }
    }
    
    // Notificar listeners globais
    if (path !== '*' && this._listeners.has('*')) {
      for (const callback of this._listeners.get('*')) {
        try {
          callback(this._state, prevState);
        } catch (e) {
          console.error('Erro em listener global:', e);
        }
      }
    }
  }
  
  _pushHistory(state) {
    // Remover estados após o índice atual (para redo)
    this._history = this._history.slice(0, this._historyIndex + 1);
    this._history.push(this._deepClone(state));
    
    // Limitar tamanho do histórico
    if (this._history.length > this._maxUndoSteps) {
      this._history.shift();
    } else {
      this._historyIndex++;
    }
  }
  
  _getByPath(obj, path) {
    if (!path) return obj;
    const parts = path.split('.');
    let current = obj;
    for (const part of parts) {
      if (current === undefined || current === null) return undefined;
      current = current[part];
    }
    return current;
  }
  
  _setByPath(obj, path, value) {
    const parts = path.split('.');
    let current = obj;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!(parts[i] in current)) {
        current[parts[i]] = {};
      }
      current = current[parts[i]];
    }
    current[parts[parts.length - 1]] = value;
  }
  
  _deepClone(obj) {
    if (obj === null || typeof obj !== 'object') return obj;
    if (obj instanceof Date) return new Date(obj);
    if (Array.isArray(obj)) return obj.map(item => this._deepClone(item));
    
    const clone = {};
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        clone[key] = this._deepClone(obj[key]);
      }
    }
    return clone;
  }
  
  _deepFreeze(obj) {
    if (obj === null || typeof obj !== 'object') return obj;
    Object.freeze(obj);
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key)) {
        this._deepFreeze(obj[key]);
      }
    }
    return obj;
  }
  
  _deepMerge(target, source) {
    const result = this._deepClone(target);
    for (const key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        if (typeof source[key] === 'object' && source[key] !== null && !Array.isArray(source[key])) {
          result[key] = this._deepMerge(result[key] || {}, source[key]);
        } else {
          result[key] = source[key];
        }
      }
    }
    return result;
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// ACTIONS - OPERAÇÕES DE ALTO NÍVEL
// ═══════════════════════════════════════════════════════════════════════════

export const actions = {
  // Configuração de átomos
  setAtom(store, atom, count) {
    store.set(`atoms.${atom}`, Math.max(0, Math.min(999, parseInt(count) || 0)));
  },
  
  setAtoms(store, atoms) {
    store.set('atoms', { ...atoms });
  },
  
  setSampleName(store, name) {
    store.set('sampleName', name);
  },
  
  // Parâmetros
  setParam(store, param, value) {
    store.set(`params.${param}`, value);
  },
  
  setParams(store, params) {
    store.merge({ params });
  },
  
  // Motor de cálculo
  setEngine(store, engine) {
    store.set('engine', engine);
  },
  
  setWasmReady(store, ready) {
    store.set('wasmReady', ready);
  },
  
  setApiAvailable(store, available) {
    store.set('apiAvailable', available);
  },
  
  // Resultado
  setResult(store, result) {
    store.set('currentResult', result);
    
    // Adicionar ao histórico
    const history = store.get('history') || [];
    const maxSize = store.get('maxHistorySize') || 50;
    const newHistory = [result, ...history].slice(0, maxSize);
    store.set('history', newHistory);
    
    // Atualizar estatísticas
    const totalAnalyses = store.get('stats.totalAnalyses') + 1;
    const avgFrequency = newHistory.reduce((sum, r) => sum + r.frequencyTHz, 0) / newHistory.length;
    store.merge({
      stats: {
        totalAnalyses,
        avgFrequency,
        lastAnalysisTime: Date.now()
      }
    });
  },
  
  clearHistory(store) {
    store.set('history', []);
  },
  
  removeFromHistory(store, id) {
    const history = store.get('history').filter(r => r.id !== id);
    store.set('history', history);
  },
  
  // UI
  setActiveTab(store, tab) {
    store.set('ui.activeTab', tab);
  },
  
  setAnalyzing(store, analyzing) {
    store.set('ui.isAnalyzing', analyzing);
  },
  
  toggleAdvanced(store) {
    store.update('ui.showAdvanced', v => !v);
  },
  
  toggleFFT(store) {
    store.update('ui.showFFT', v => !v);
  },
  
  // Áudio
  setAudioEnabled(store, enabled) {
    store.set('audio.enabled', enabled);
  },
  
  setAudioWaveform(store, waveform) {
    store.set('audio.waveform', waveform);
  },
  
  setAudioVolume(store, volume) {
    store.set('audio.volume', volume);
  },
  
  // Preset
  loadPreset(store, preset) {
    store.merge({
      atoms: { ...preset.atoms },
      sampleName: preset.name
    });
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// SELECTORS - DERIVAÇÕES DO ESTADO
// ═══════════════════════════════════════════════════════════════════════════

export const selectors = {
  getTotalAtoms(state) {
    return Object.values(state.atoms).reduce((a, b) => a + b, 0);
  },
  
  getFormula(state) {
    const subscripts = '₀₁₂₃₄₅₆₇₈₉';
    const toSubscript = n => n.toString().split('').map(d => subscripts[d]).join('');
    
    let formula = '';
    for (const atom of ['C', 'H', 'O', 'N', 'P', 'S']) {
      if (state.atoms[atom] > 0) {
        formula += atom + (state.atoms[atom] > 1 ? toSubscript(state.atoms[atom]) : '');
      }
    }
    return formula || '---';
  },
  
  getAvailableEngines(state) {
    const engines = ['js'];
    if (state.wasmReady) engines.push('wasm');
    if (state.apiAvailable) engines.push('api');
    return engines;
  },
  
  getHistoryStats(state) {
    const history = state.history;
    if (history.length === 0) return null;
    
    const frequencies = history.map(r => r.frequencyTHz);
    return {
      count: history.length,
      min: Math.min(...frequencies),
      max: Math.max(...frequencies),
      avg: frequencies.reduce((a, b) => a + b, 0) / frequencies.length,
      stdDev: calculateStdDev(frequencies)
    };
  }
};

function calculateStdDev(values) {
  const avg = values.reduce((a, b) => a + b, 0) / values.length;
  const squareDiffs = values.map(v => Math.pow(v - avg, 2));
  return Math.sqrt(squareDiffs.reduce((a, b) => a + b, 0) / values.length);
}

// ═══════════════════════════════════════════════════════════════════════════
// INSTÂNCIA GLOBAL
// ═══════════════════════════════════════════════════════════════════════════

export const store = new Store(initialState);

// Middleware de logging (opcional)
if (typeof window !== 'undefined' && window.location?.search?.includes('debug')) {
  store.use((path, value, prevState) => {
    console.log(`[Store] ${path}:`, value);
    return value;
  });
}

export default store;

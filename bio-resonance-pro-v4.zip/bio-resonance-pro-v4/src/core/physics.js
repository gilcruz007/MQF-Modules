/**
 * Bio-Resonance Pro v4.0 - Core Physics Module
 * Frequências moleculares em THz (Terahertz) - Padrão científico
 * 
 * @module core/physics
 * @version 4.0.0
 */

// ═══════════════════════════════════════════════════════════════════════════
// CONSTANTES FÍSICAS FUNDAMENTAIS
// ═══════════════════════════════════════════════════════════════════════════

export const PHYSICAL_CONSTANTS = {
  PHI: 1.618033988749895,                    // Razão áurea
  PLANCK: 6.62607015e-34,                    // Constante de Planck (J·s)
  BOLTZMANN: 1.380649e-23,                   // Constante de Boltzmann (J/K)
  AVOGADRO: 6.02214076e23,                   // Número de Avogadro (mol⁻¹)
  SPEED_OF_LIGHT: 2.99792458e8,              // Velocidade da luz (m/s)
  AMU_TO_KG: 1.66053906660e-27,              // Conversão u para kg
};

// Pesos atômicos em unidades de massa atômica (u)
export const ATOM_DATA = {
  C: { mass: 12.011, color: '#4a5568', name: 'Carbono', electronegativity: 2.55 },
  H: { mass: 1.008,  color: '#e2e8f0', name: 'Hidrogénio', electronegativity: 2.20 },
  O: { mass: 15.999, color: '#ef4444', name: 'Oxigénio', electronegativity: 3.44 },
  N: { mass: 14.007, color: '#3b82f6', name: 'Azoto', electronegativity: 3.04 },
  P: { mass: 30.974, color: '#f97316', name: 'Fósforo', electronegativity: 2.19 },
  S: { mass: 32.065, color: '#eab308', name: 'Enxofre', electronegativity: 2.58 }
};

// Constantes de força de ligação típicas (N/m)
export const BOND_FORCE_CONSTANTS = {
  'C-C': 500,
  'C=C': 960,
  'C-H': 500,
  'C-O': 450,
  'C=O': 1200,
  'O-H': 750,
  'N-H': 640,
  'C-N': 500,
  'C≡N': 1800,
  'P-O': 500,
  'S-H': 400
};

// Moléculas predefinidas com dados completos
export const PRESETS = {
  glucose: { 
    name: 'Glicose', 
    formula: 'C₆H₁₂O₆',
    atoms: { C: 6, H: 12, O: 6, N: 0, P: 0, S: 0 },
    icon: '🍬',
    description: 'Açúcar fundamental para metabolismo celular'
  },
  water: { 
    name: 'Água', 
    formula: 'H₂O',
    atoms: { C: 0, H: 2, O: 1, N: 0, P: 0, S: 0 },
    icon: '💧',
    description: 'Solvente universal da vida'
  },
  atp: { 
    name: 'ATP', 
    formula: 'C₁₀H₁₆N₅O₁₃P₃',
    atoms: { C: 10, H: 16, O: 13, N: 5, P: 3, S: 0 },
    icon: '⚡',
    description: 'Moeda energética celular'
  },
  caffeine: { 
    name: 'Cafeína', 
    formula: 'C₈H₁₀N₄O₂',
    atoms: { C: 8, H: 10, O: 2, N: 4, P: 0, S: 0 },
    icon: '☕',
    description: 'Estimulante do sistema nervoso central'
  },
  ethanol: { 
    name: 'Etanol', 
    formula: 'C₂H₆O',
    atoms: { C: 2, H: 6, O: 1, N: 0, P: 0, S: 0 },
    icon: '🍷',
    description: 'Álcool etílico'
  },
  aspirin: { 
    name: 'Aspirina', 
    formula: 'C₉H₈O₄',
    atoms: { C: 9, H: 8, O: 4, N: 0, P: 0, S: 0 },
    icon: '💊',
    description: 'Ácido acetilsalicílico - anti-inflamatório'
  },
  dopamine: {
    name: 'Dopamina',
    formula: 'C₈H₁₁NO₂',
    atoms: { C: 8, H: 11, O: 2, N: 1, P: 0, S: 0 },
    icon: '🧠',
    description: 'Neurotransmissor de recompensa'
  },
  serotonin: {
    name: 'Serotonina',
    formula: 'C₁₀H₁₂N₂O',
    atoms: { C: 10, H: 12, O: 1, N: 2, P: 0, S: 0 },
    icon: '😊',
    description: 'Neurotransmissor do bem-estar'
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// FUNÇÕES DE CÁLCULO MOLECULAR
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Calcula a massa molecular total
 * @param {Object} atoms - Contagem de átomos {C, H, O, N, P, S}
 * @returns {number} Massa em g/mol
 */
export function calculateMolecularMass(atoms) {
  return Object.entries(atoms).reduce((mass, [atom, count]) => {
    return mass + (ATOM_DATA[atom]?.mass || 0) * count;
  }, 0);
}

/**
 * Calcula a massa reduzida média da molécula
 * @param {Object} atoms - Contagem de átomos
 * @returns {number} Massa reduzida em kg
 */
export function calculateReducedMass(atoms) {
  const masses = [];
  for (const [atom, count] of Object.entries(atoms)) {
    if (count > 0) {
      const massKg = ATOM_DATA[atom].mass * PHYSICAL_CONSTANTS.AMU_TO_KG;
      for (let i = 0; i < count; i++) {
        masses.push(massKg);
      }
    }
  }
  
  if (masses.length < 2) return masses[0] || 1e-27;
  
  // Média harmônica para massa reduzida
  const sumInverse = masses.reduce((sum, m) => sum + 1/m, 0);
  return masses.length / sumInverse;
}

/**
 * Calcula índice de polaridade molecular
 * Baseado em eletronegatividade ponderada
 * @param {Object} atoms - Contagem de átomos
 * @returns {number} Índice de polaridade (0-1)
 */
export function calculatePolarity(atoms) {
  const totalAtoms = Object.values(atoms).reduce((a, b) => a + b, 0);
  if (totalAtoms === 0) return 0;
  
  let weightedSum = 0;
  let refElectronegativity = 2.5; // Valor de referência (carbono)
  
  for (const [atom, count] of Object.entries(atoms)) {
    if (count > 0 && ATOM_DATA[atom]) {
      const deviation = Math.abs(ATOM_DATA[atom].electronegativity - refElectronegativity);
      weightedSum += deviation * count;
    }
  }
  
  return Math.min(1, weightedSum / (totalAtoms * 1.5));
}

/**
 * Estima o número de modos vibracionais
 * @param {Object} atoms - Contagem de átomos
 * @returns {Object} { linear: number, nonLinear: number }
 */
export function estimateVibrationalModes(atoms) {
  const N = Object.values(atoms).reduce((a, b) => a + b, 0);
  if (N < 2) return { linear: 0, nonLinear: 0 };
  
  // Para moléculas lineares: 3N - 5
  // Para moléculas não-lineares: 3N - 6
  return {
    linear: 3 * N - 5,
    nonLinear: 3 * N - 6,
    total: N > 2 ? 3 * N - 6 : 3 * N - 5
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// CÁLCULO DE FREQUÊNCIA PRINCIPAL - THz (PADRÃO CIENTÍFICO)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Calcula frequência de ressonância molecular em THz
 * 
 * Modelo físico baseado em:
 * f = (1/2π) × √(k_eff/μ)
 * 
 * Onde:
 * - k_eff = constante de força efetiva (modificada por fatores biomiméticos)
 * - μ = massa reduzida
 * 
 * @param {Object} params - Parâmetros de análise
 * @param {Object} params.atoms - Contagem de átomos {C, H, O, N, P, S}
 * @param {number} params.delta - Desvio estrutural (0-1)
 * @param {number} params.intensity - Intensidade do campo (0-100)
 * @param {number} params.temperature - Temperatura em Kelvin
 * @param {string} params.name - Nome da amostra
 * @returns {Object} Resultado da análise com frequência em THz
 */
export function computeFrequency(params) {
  const { atoms, delta, intensity, temperature, name } = params;
  
  // Validação de entrada
  const totalAtoms = Object.values(atoms).reduce((a, b) => a + b, 0);
  if (totalAtoms === 0) {
    return createEmptyResult(name);
  }
  
  // 1. Propriedades moleculares básicas
  const molecularMass = calculateMolecularMass(atoms);
  const reducedMass = calculateReducedMass(atoms);
  const polarity = calculatePolarity(atoms);
  const modes = estimateVibrationalModes(atoms);
  
  // 2. Constante de força efetiva (N/m)
  // Modelo biomimético com influência de phi
  const { PHI } = PHYSICAL_CONSTANTS;
  const baseForceConstant = 500; // N/m (típico para ligações C-C)
  const polarityModifier = 1 + polarity * 0.5;
  const deltaEffect = Math.log1p(delta * PHI * (1 + polarity));
  const k_eff = baseForceConstant * polarityModifier * (1 + deltaEffect);
  
  // 3. Fator de temperatura (distribuição de Boltzmann)
  const T_ref = 310; // Temperatura de referência (37°C corpo humano)
  const tempFactor = Math.exp((temperature - T_ref) / (2 * T_ref));
  
  // 4. Fator de intensidade de campo
  const intensityFactor = 0.5 + (intensity / 100) * 0.5;
  
  // 5. Cálculo da frequência fundamental
  // f = (1/2π) × √(k/μ) convertido para THz
  const freqRad = Math.sqrt(k_eff / reducedMass);
  const freqHz = freqRad / (2 * Math.PI);
  const freqTHz = freqHz * 1e-12; // Conversão para THz
  
  // 6. Aplicar modificadores
  const resonanceFreqTHz = freqTHz * tempFactor * intensityFactor;
  
  // 7. Fator geométrico (phi-based)
  const geoFactor = Math.log1p(delta * PHI * (1 + polarity));
  
  // 8. Determinação do modo de ressonância
  let mode, modeClass, modeDescription;
  if (resonanceFreqTHz < 5) {
    mode = 'REGENERAÇÃO';
    modeClass = 'regeneration';
    modeDescription = 'Frequência ideal para processos de regeneração celular';
  } else if (resonanceFreqTHz < 20) {
    mode = 'EQUILÍBRIO';
    modeClass = 'equilibrium';
    modeDescription = 'Zona de equilíbrio energético molecular';
  } else if (resonanceFreqTHz < 50) {
    mode = 'ATIVAÇÃO';
    modeClass = 'activation';
    modeDescription = 'Frequência de ativação de processos metabólicos';
  } else {
    mode = 'ISOLAMENTO';
    modeClass = 'isolation';
    modeDescription = 'Frequência de isolamento - alta energia vibracional';
  }
  
  // 9. Cálculo de modos vibracionais simulados
  const vibrationalModes = generateVibrationalModes(atoms, resonanceFreqTHz);
  
  // 10. Cálculo de energia vibracional
  const energyJoules = PHYSICAL_CONSTANTS.PLANCK * resonanceFreqTHz * 1e12;
  const energyEv = energyJoules / 1.602176634e-19;
  const energyKjMol = energyJoules * PHYSICAL_CONSTANTS.AVOGADRO / 1000;
  
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    name,
    
    // Frequências
    frequencyTHz: resonanceFreqTHz,
    frequencyHz: resonanceFreqTHz * 1e12,
    wavelengthUm: (PHYSICAL_CONSTANTS.SPEED_OF_LIGHT / (resonanceFreqTHz * 1e12)) * 1e6,
    
    // Fatores
    geoFactor,
    phiFactor: PHI * (1 + delta),
    
    // Modo
    mode,
    modeClass,
    modeDescription,
    
    // Propriedades moleculares
    molecularMass,
    reducedMass,
    polarity,
    vibrationalModes,
    modesCount: modes,
    
    // Energia
    energy: {
      joules: energyJoules,
      electronVolts: energyEv,
      kjPerMol: energyKjMol
    },
    
    // Parâmetros de entrada
    params: { atoms: { ...atoms }, delta, intensity, temperature },
    
    // Metadados
    timestamp: Date.now(),
    engine: 'js',
    version: '4.0.0'
  };
}

/**
 * Gera modos vibracionais simulados
 * @param {Object} atoms - Contagem de átomos
 * @param {number} baseFreq - Frequência base em THz
 * @returns {Array} Lista de modos vibracionais
 */
function generateVibrationalModes(atoms, baseFreq) {
  const modes = [];
  const modeTypes = [
    { type: 'stretching', label: 'Estiramento', factor: 1.0 },
    { type: 'bending', label: 'Flexão', factor: 0.5 },
    { type: 'rocking', label: 'Balanço', factor: 0.3 },
    { type: 'wagging', label: 'Oscilação', factor: 0.35 },
    { type: 'twisting', label: 'Torção', factor: 0.25 }
  ];
  
  // Gerar modos baseados na composição
  for (const [atom, count] of Object.entries(atoms)) {
    if (count > 0 && ATOM_DATA[atom]) {
      for (const modeType of modeTypes) {
        const massEffect = Math.sqrt(12 / ATOM_DATA[atom].mass); // Normalizado por carbono
        const freq = baseFreq * modeType.factor * massEffect * (1 + Math.random() * 0.1);
        
        if (modes.length < 20) { // Limitar número de modos exibidos
          modes.push({
            type: modeType.type,
            label: `${modeType.label} ${atom}`,
            frequency: freq,
            intensity: Math.random() * 0.5 + 0.5,
            atom
          });
        }
      }
    }
  }
  
  return modes.sort((a, b) => a.frequency - b.frequency);
}

/**
 * Cria resultado vazio para casos sem átomos
 */
function createEmptyResult(name) {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    name: name || 'Vazio',
    frequencyTHz: 0,
    frequencyHz: 0,
    wavelengthUm: 0,
    geoFactor: 0,
    phiFactor: PHYSICAL_CONSTANTS.PHI,
    mode: 'N/A',
    modeClass: 'empty',
    modeDescription: 'Adicione átomos para calcular',
    molecularMass: 0,
    reducedMass: 0,
    polarity: 0,
    vibrationalModes: [],
    modesCount: { linear: 0, nonLinear: 0, total: 0 },
    energy: { joules: 0, electronVolts: 0, kjPerMol: 0 },
    params: { atoms: { C: 0, H: 0, O: 0, N: 0, P: 0, S: 0 }, delta: 0, intensity: 50, temperature: 310 },
    timestamp: Date.now(),
    engine: 'js',
    version: '4.0.0'
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// ANÁLISE COMPARATIVA E CLUSTERING
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Compara duas análises
 * @param {Object} a - Primeira análise
 * @param {Object} b - Segunda análise
 * @returns {Object} Resultado da comparação
 */
export function compareAnalyses(a, b) {
  const freqDiff = Math.abs(a.frequencyTHz - b.frequencyTHz);
  const massDiff = Math.abs(a.molecularMass - b.molecularMass);
  const polarityDiff = Math.abs(a.polarity - b.polarity);
  
  // Índice de similaridade (0-100)
  const freqSimilarity = Math.max(0, 100 - (freqDiff / Math.max(a.frequencyTHz, b.frequencyTHz)) * 100);
  const massSimilarity = Math.max(0, 100 - (massDiff / Math.max(a.molecularMass, b.molecularMass)) * 100);
  const polaritySimilarity = Math.max(0, 100 - polarityDiff * 100);
  
  const overallSimilarity = (freqSimilarity + massSimilarity + polaritySimilarity) / 3;
  
  return {
    samples: [a.name, b.name],
    frequency: {
      difference: freqDiff,
      unit: 'THz',
      percentDiff: (freqDiff / Math.max(a.frequencyTHz, b.frequencyTHz)) * 100,
      similarity: freqSimilarity
    },
    mass: {
      difference: massDiff,
      unit: 'g/mol',
      similarity: massSimilarity
    },
    polarity: {
      difference: polarityDiff,
      similarity: polaritySimilarity
    },
    overallSimilarity,
    compatible: overallSimilarity > 70,
    resonanceMatch: freqDiff < 1 // Menos de 1 THz de diferença
  };
}

/**
 * Agrupa análises por similaridade (clustering básico)
 * @param {Array} analyses - Lista de análises
 * @param {number} threshold - Limiar de similaridade (0-100)
 * @returns {Array} Clusters de análises
 */
export function clusterAnalyses(analyses, threshold = 70) {
  const clusters = [];
  const assigned = new Set();
  
  for (let i = 0; i < analyses.length; i++) {
    if (assigned.has(i)) continue;
    
    const cluster = [analyses[i]];
    assigned.add(i);
    
    for (let j = i + 1; j < analyses.length; j++) {
      if (assigned.has(j)) continue;
      
      const comparison = compareAnalyses(analyses[i], analyses[j]);
      if (comparison.overallSimilarity >= threshold) {
        cluster.push(analyses[j]);
        assigned.add(j);
      }
    }
    
    clusters.push({
      id: clusters.length + 1,
      members: cluster,
      centroid: calculateClusterCentroid(cluster),
      avgFrequency: cluster.reduce((sum, a) => sum + a.frequencyTHz, 0) / cluster.length,
      avgMass: cluster.reduce((sum, a) => sum + a.molecularMass, 0) / cluster.length
    });
  }
  
  return clusters;
}

function calculateClusterCentroid(cluster) {
  return {
    frequencyTHz: cluster.reduce((sum, a) => sum + a.frequencyTHz, 0) / cluster.length,
    molecularMass: cluster.reduce((sum, a) => sum + a.molecularMass, 0) / cluster.length,
    polarity: cluster.reduce((sum, a) => sum + a.polarity, 0) / cluster.length
  };
}

export default {
  PHYSICAL_CONSTANTS,
  ATOM_DATA,
  PRESETS,
  BOND_FORCE_CONSTANTS,
  calculateMolecularMass,
  calculateReducedMass,
  calculatePolarity,
  estimateVibrationalModes,
  computeFrequency,
  compareAnalyses,
  clusterAnalyses
};

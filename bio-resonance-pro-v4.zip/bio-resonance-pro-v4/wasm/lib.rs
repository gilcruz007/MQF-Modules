//! Bio-Resonance Pro v4.0 - WASM Module
//! Implementação de alta performance em Rust para cálculos de frequência molecular
//! 
//! Para compilar:
//! ```bash
//! wasm-pack build --target web
//! ```

use wasm_bindgen::prelude::*;
use std::f64::consts::PI;

// ═══════════════════════════════════════════════════════════════════════════
// CONSTANTES FÍSICAS
// ═══════════════════════════════════════════════════════════════════════════

const PHI: f64 = 1.618033988749895;
const PLANCK: f64 = 6.62607015e-34;
const BOLTZMANN: f64 = 1.380649e-23;
const AMU_TO_KG: f64 = 1.66053906660e-27;
const SPEED_OF_LIGHT: f64 = 2.99792458e8;

// Massas atômicas (u)
const MASS_C: f64 = 12.011;
const MASS_H: f64 = 1.008;
const MASS_O: f64 = 15.999;
const MASS_N: f64 = 14.007;
const MASS_P: f64 = 30.974;
const MASS_S: f64 = 32.065;

// Eletronegatividades de Pauling
const EN_C: f64 = 2.55;
const EN_H: f64 = 2.20;
const EN_O: f64 = 3.44;
const EN_N: f64 = 3.04;
const EN_P: f64 = 2.19;
const EN_S: f64 = 2.58;

// ═══════════════════════════════════════════════════════════════════════════
// ESTRUTURAS
// ═══════════════════════════════════════════════════════════════════════════

#[wasm_bindgen]
pub struct MolecularAnalysis {
    frequency_thz: f64,
    frequency_hz: f64,
    wavelength_um: f64,
    geo_factor: f64,
    phi_factor: f64,
    molecular_mass: f64,
    reduced_mass: f64,
    polarity: f64,
    mode: String,
    mode_class: String,
    energy_joules: f64,
    energy_ev: f64,
    energy_kj_mol: f64,
}

#[wasm_bindgen]
impl MolecularAnalysis {
    #[wasm_bindgen(getter)]
    pub fn frequency_thz(&self) -> f64 { self.frequency_thz }
    
    #[wasm_bindgen(getter)]
    pub fn frequency_hz(&self) -> f64 { self.frequency_hz }
    
    #[wasm_bindgen(getter)]
    pub fn wavelength_um(&self) -> f64 { self.wavelength_um }
    
    #[wasm_bindgen(getter)]
    pub fn geo_factor(&self) -> f64 { self.geo_factor }
    
    #[wasm_bindgen(getter)]
    pub fn phi_factor(&self) -> f64 { self.phi_factor }
    
    #[wasm_bindgen(getter)]
    pub fn molecular_mass(&self) -> f64 { self.molecular_mass }
    
    #[wasm_bindgen(getter)]
    pub fn reduced_mass(&self) -> f64 { self.reduced_mass }
    
    #[wasm_bindgen(getter)]
    pub fn polarity(&self) -> f64 { self.polarity }
    
    #[wasm_bindgen(getter)]
    pub fn mode(&self) -> String { self.mode.clone() }
    
    #[wasm_bindgen(getter)]
    pub fn mode_class(&self) -> String { self.mode_class.clone() }
    
    #[wasm_bindgen(getter)]
    pub fn energy_joules(&self) -> f64 { self.energy_joules }
    
    #[wasm_bindgen(getter)]
    pub fn energy_ev(&self) -> f64 { self.energy_ev }
    
    #[wasm_bindgen(getter)]
    pub fn energy_kj_mol(&self) -> f64 { self.energy_kj_mol }
}

// ═══════════════════════════════════════════════════════════════════════════
// FUNÇÕES AUXILIARES
// ═══════════════════════════════════════════════════════════════════════════

/// Calcula massa molecular total em g/mol
#[wasm_bindgen]
pub fn calculate_molecular_mass(c: i32, h: i32, o: i32, n: i32, p: i32, s: i32) -> f64 {
    (c as f64 * MASS_C) +
    (h as f64 * MASS_H) +
    (o as f64 * MASS_O) +
    (n as f64 * MASS_N) +
    (p as f64 * MASS_P) +
    (s as f64 * MASS_S)
}

/// Calcula massa reduzida em kg usando média harmônica
#[wasm_bindgen]
pub fn calculate_reduced_mass(c: i32, h: i32, o: i32, n: i32, p: i32, s: i32) -> f64 {
    let mut masses: Vec<f64> = Vec::new();
    
    for _ in 0..c { masses.push(MASS_C * AMU_TO_KG); }
    for _ in 0..h { masses.push(MASS_H * AMU_TO_KG); }
    for _ in 0..o { masses.push(MASS_O * AMU_TO_KG); }
    for _ in 0..n { masses.push(MASS_N * AMU_TO_KG); }
    for _ in 0..p { masses.push(MASS_P * AMU_TO_KG); }
    for _ in 0..s { masses.push(MASS_S * AMU_TO_KG); }
    
    if masses.len() < 2 {
        return masses.first().copied().unwrap_or(1e-27);
    }
    
    let sum_inverse: f64 = masses.iter().map(|&m| 1.0 / m).sum();
    masses.len() as f64 / sum_inverse
}

/// Calcula índice de polaridade baseado em eletronegatividade
#[wasm_bindgen]
pub fn calculate_polarity(c: i32, h: i32, o: i32, n: i32, p: i32, s: i32) -> f64 {
    let total_atoms = c + h + o + n + p + s;
    if total_atoms == 0 {
        return 0.0;
    }
    
    let ref_en = 2.5; // Carbono como referência
    
    let weighted_sum = 
        (c as f64 * (EN_C - ref_en).abs()) +
        (h as f64 * (EN_H - ref_en).abs()) +
        (o as f64 * (EN_O - ref_en).abs()) +
        (n as f64 * (EN_N - ref_en).abs()) +
        (p as f64 * (EN_P - ref_en).abs()) +
        (s as f64 * (EN_S - ref_en).abs());
    
    (weighted_sum / (total_atoms as f64 * 1.5)).min(1.0)
}

/// Estima número de modos vibracionais (3N-6 para não-lineares)
#[wasm_bindgen]
pub fn estimate_vibrational_modes(c: i32, h: i32, o: i32, n: i32, p: i32, s: i32) -> i32 {
    let n_atoms = c + h + o + n + p + s;
    if n_atoms < 2 {
        return 0;
    }
    if n_atoms == 2 {
        return 1; // Molécula diatômica
    }
    3 * n_atoms - 6 // Molécula não-linear
}

// ═══════════════════════════════════════════════════════════════════════════
// FUNÇÃO PRINCIPAL DE CÁLCULO
// ═══════════════════════════════════════════════════════════════════════════

/// Calcula frequência de ressonância molecular em THz
/// 
/// # Argumentos
/// * `c`, `h`, `o`, `n`, `p`, `s` - Contagem de átomos
/// * `delta` - Desvio estrutural (0-1)
/// * `intensity` - Intensidade do campo (0-100)
/// * `temperature` - Temperatura em Kelvin
/// 
/// # Retorna
/// Estrutura MolecularAnalysis com todos os resultados
#[wasm_bindgen]
pub fn compute_frequency(
    c: i32, h: i32, o: i32, n: i32, p: i32, s: i32,
    delta: f64,
    intensity: f64,
    temperature: f64
) -> MolecularAnalysis {
    let total_atoms = c + h + o + n + p + s;
    
    // Caso vazio
    if total_atoms == 0 {
        return MolecularAnalysis {
            frequency_thz: 0.0,
            frequency_hz: 0.0,
            wavelength_um: 0.0,
            geo_factor: 0.0,
            phi_factor: PHI,
            molecular_mass: 0.0,
            reduced_mass: 0.0,
            polarity: 0.0,
            mode: "N/A".to_string(),
            mode_class: "empty".to_string(),
            energy_joules: 0.0,
            energy_ev: 0.0,
            energy_kj_mol: 0.0,
        };
    }
    
    // 1. Propriedades moleculares
    let molecular_mass = calculate_molecular_mass(c, h, o, n, p, s);
    let reduced_mass = calculate_reduced_mass(c, h, o, n, p, s);
    let polarity = calculate_polarity(c, h, o, n, p, s);
    
    // 2. Constante de força efetiva (N/m)
    let base_force_constant = 500.0;
    let polarity_modifier = 1.0 + polarity * 0.5;
    let delta_effect = (delta * PHI * (1.0 + polarity)).ln_1p();
    let k_eff = base_force_constant * polarity_modifier * (1.0 + delta_effect);
    
    // 3. Fatores de modificação
    let t_ref = 310.0; // Temperatura de referência (37°C)
    let temp_factor = ((temperature - t_ref) / (2.0 * t_ref)).exp();
    let intensity_factor = 0.5 + (intensity / 100.0) * 0.5;
    
    // 4. Cálculo da frequência
    // f = (1/2π) × √(k/μ)
    let freq_rad = (k_eff / reduced_mass).sqrt();
    let freq_hz = freq_rad / (2.0 * PI);
    let freq_thz = freq_hz * 1e-12;
    
    // 5. Aplicar modificadores
    let resonance_freq_thz = freq_thz * temp_factor * intensity_factor;
    let resonance_freq_hz = resonance_freq_thz * 1e12;
    
    // 6. Comprimento de onda
    let wavelength_um = (SPEED_OF_LIGHT / resonance_freq_hz) * 1e6;
    
    // 7. Fator geométrico
    let geo_factor = (delta * PHI * (1.0 + polarity)).ln_1p();
    let phi_factor = PHI * (1.0 + delta);
    
    // 8. Determinação do modo
    let (mode, mode_class) = if resonance_freq_thz < 5.0 {
        ("REGENERAÇÃO", "regeneration")
    } else if resonance_freq_thz < 20.0 {
        ("EQUILÍBRIO", "equilibrium")
    } else if resonance_freq_thz < 50.0 {
        ("ATIVAÇÃO", "activation")
    } else {
        ("ISOLAMENTO", "isolation")
    };
    
    // 9. Energia vibracional
    let energy_joules = PLANCK * resonance_freq_hz;
    let energy_ev = energy_joules / 1.602176634e-19;
    let energy_kj_mol = energy_joules * 6.02214076e23 / 1000.0;
    
    MolecularAnalysis {
        frequency_thz: resonance_freq_thz,
        frequency_hz: resonance_freq_hz,
        wavelength_um,
        geo_factor,
        phi_factor,
        molecular_mass,
        reduced_mass,
        polarity,
        mode: mode.to_string(),
        mode_class: mode_class.to_string(),
        energy_joules,
        energy_ev,
        energy_kj_mol,
    }
}

/// Calcula apenas a frequência em THz (versão simplificada)
#[wasm_bindgen]
pub fn compute_frequency_simple(
    c: i32, h: i32, o: i32, n: i32, p: i32, s: i32,
    delta: f64,
    intensity: f64,
    temperature: f64
) -> f64 {
    let result = compute_frequency(c, h, o, n, p, s, delta, intensity, temperature);
    result.frequency_thz
}

/// Verifica se WASM está carregado corretamente
#[wasm_bindgen]
pub fn wasm_ready() -> bool {
    true
}

/// Retorna versão do módulo WASM
#[wasm_bindgen]
pub fn wasm_version() -> String {
    "4.0.0".to_string()
}

// ═══════════════════════════════════════════════════════════════════════════
// ANÁLISE EM LOTE
// ═══════════════════════════════════════════════════════════════════════════

/// Calcula frequências para múltiplos valores de delta
/// Útil para gerar curvas de ressonância
#[wasm_bindgen]
pub fn compute_frequency_range(
    c: i32, h: i32, o: i32, n: i32, p: i32, s: i32,
    intensity: f64,
    temperature: f64,
    delta_start: f64,
    delta_end: f64,
    steps: i32
) -> Vec<f64> {
    let mut results = Vec::with_capacity(steps as usize);
    
    for i in 0..steps {
        let delta = delta_start + (delta_end - delta_start) * (i as f64) / ((steps - 1) as f64);
        let freq = compute_frequency_simple(c, h, o, n, p, s, delta, intensity, temperature);
        results.push(freq);
    }
    
    results
}

/// Calcula estatísticas básicas para um array de frequências
#[wasm_bindgen]
pub fn calculate_stats(frequencies: Vec<f64>) -> Vec<f64> {
    if frequencies.is_empty() {
        return vec![0.0, 0.0, 0.0, 0.0];
    }
    
    let n = frequencies.len() as f64;
    let mean: f64 = frequencies.iter().sum::<f64>() / n;
    let min = frequencies.iter().cloned().fold(f64::INFINITY, f64::min);
    let max = frequencies.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
    
    let variance: f64 = frequencies.iter()
        .map(|&x| (x - mean).powi(2))
        .sum::<f64>() / n;
    let std_dev = variance.sqrt();
    
    vec![mean, min, max, std_dev]
}

// ═══════════════════════════════════════════════════════════════════════════
// TESTES
// ═══════════════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    
    #[test]
    fn test_molecular_mass() {
        // Água: H2O
        let mass = calculate_molecular_mass(0, 2, 1, 0, 0, 0);
        assert!((mass - 18.015).abs() < 0.01);
        
        // Glicose: C6H12O6
        let mass = calculate_molecular_mass(6, 12, 6, 0, 0, 0);
        assert!((mass - 180.156).abs() < 0.1);
    }
    
    #[test]
    fn test_polarity() {
        // Água deve ter alta polaridade
        let pol = calculate_polarity(0, 2, 1, 0, 0, 0);
        assert!(pol > 0.3);
    }
    
    #[test]
    fn test_frequency_computation() {
        let result = compute_frequency(6, 12, 6, 0, 0, 0, 0.2, 50.0, 310.0);
        assert!(result.frequency_thz > 0.0);
        assert!(result.frequency_thz < 100.0);
    }
    
    #[test]
    fn test_wasm_ready() {
        assert!(wasm_ready());
    }
}

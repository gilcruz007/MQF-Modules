# Bio-Resonance Pro v4.0

**Análise de Frequência Molecular em THz (Terahertz)**

Sistema avançado para cálculo de frequências de ressonância molecular utilizando modelos físicos baseados em mecânica quântica e dinâmica molecular.

## 🚀 Novidades v4.0

### Frequência Corrigida - Padrão THz
- Frequências calculadas em **Terahertz (THz)** - o padrão científico para vibrações moleculares
- Modelo físico: `f = (1/2π) × √(k_eff/μ)`
- Faixa típica: 0.1 - 100 THz

### Arquitetura Modular ES Modules
```
src/
├── core/physics.js      # Cálculos físicos e constantes
├── state/store.js       # Gestão de estado reativa
├── audio/sonification.js # Áudio e sonificação
└── scientific/analysis.js # FFT, clustering, exportação PDF
```

### WASM/Rust Real
- Implementação em Rust com `wasm-bindgen`
- Performance 10-100x superior para cálculos intensivos
- Compile com: `wasm-pack build --target web`

### API Python FastAPI
- Backend RESTful completo
- Endpoints: `/api/analyze`, `/api/compare`, `/api/stats`
- JSON schema versionado
- Fallback automático JS → API

### Funcionalidades Científicas
- **FFT Conceitual**: Análise de espectro simulada
- **Modos Vibracionais**: Stretching, bending, rocking, wagging, twisting
- **Clustering K-Means**: Agrupamento de análises por similaridade
- **Exportação PDF**: Relatórios científicos formatados

## 📦 Estrutura do Projeto

```
bio-resonance-pro-v4/
├── Bio_Resonance_Pro_v4.html  # Aplicação principal (standalone)
├── src/
│   ├── core/physics.js        # Constantes físicas e cálculos
│   ├── state/store.js         # Estado reativo
│   ├── audio/sonification.js  # Engine de áudio
│   └── scientific/analysis.js # FFT, stats, clustering
├── wasm/
│   ├── lib.rs                 # Implementação Rust
│   └── Cargo.toml             # Configuração Rust/WASM
└── backend/
    ├── main.py                # API FastAPI
    └── requirements.txt       # Dependências Python
```

## 🎯 Início Rápido

### Modo Standalone (HTML)
```bash
# Abra diretamente no navegador
open Bio_Resonance_Pro_v4.html
```

### Com API Python
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### Com WASM/Rust
```bash
cd wasm
wasm-pack build --target web
# Os arquivos serão gerados em pkg/
```

## 🔬 Modelo Físico

### Frequência de Ressonância
```
f = (1/2π) × √(k_eff/μ)

Onde:
- k_eff = constante de força efetiva (N/m)
- μ = massa reduzida (kg)
- f = frequência em Hz, convertida para THz
```

### Fatores de Modificação
- **Polaridade**: Baseada em eletronegatividade de Pauling
- **Temperatura**: Distribuição de Boltzmann
- **Fator Phi (φ)**: Razão áurea biomimética
- **Delta (Δ)**: Desvio estrutural

### Modos de Ressonância
| Frequência | Modo | Descrição |
|------------|------|-----------|
| < 5 THz | REGENERAÇÃO | Processos de regeneração celular |
| 5-20 THz | EQUILÍBRIO | Zona de equilíbrio energético |
| 20-50 THz | ATIVAÇÃO | Ativação metabólica |
| > 50 THz | ISOLAMENTO | Alta energia vibracional |

## 📊 API Endpoints

### POST /api/analyze
```json
{
  "name": "Glicose",
  "atoms": {"C": 6, "H": 12, "O": 6, "N": 0, "P": 0, "S": 0},
  "params": {"delta": 0.2, "intensity": 50, "temperature": 310}
}
```

### POST /api/compare
Compara duas análises e retorna índice de similaridade.

### POST /api/stats
Calcula estatísticas descritivas para conjunto de análises.

### GET /api/presets
Retorna moléculas predefinidas.

## 🎨 Interface

- **Presets**: Glicose, Água, ATP, Cafeína, Etanol, Aspirina, Dopamina, Serotonina
- **Visualizações**: Curva de ressonância, espectro vibracional, forma de onda
- **Áudio**: Sonificação em tempo real com múltiplas formas de onda
- **Comparação**: Análise de diferença entre amostras
- **Histórico**: Últimas 50 análises com restauração rápida

## 📐 Constantes Físicas

```javascript
const PHI = 1.618033988749895;        // Razão áurea
const PLANCK = 6.62607015e-34;        // J·s
const BOLTZMANN = 1.380649e-23;       // J/K
const AVOGADRO = 6.02214076e23;       // mol⁻¹
const SPEED_OF_LIGHT = 2.99792458e8;  // m/s
const AMU_TO_KG = 1.66053906660e-27;  // kg
```

## ⚠️ Aviso

Este software é fornecido **apenas para fins educacionais e de pesquisa**. Os resultados são baseados em modelos computacionais simplificados e não devem ser utilizados para diagnósticos ou tratamentos médicos.

## 📄 Licença

MIT License - Ver LICENSE para detalhes.

---

**Bio-Resonance Pro v4.0** | Desenvolvido com 🧬 e φ
